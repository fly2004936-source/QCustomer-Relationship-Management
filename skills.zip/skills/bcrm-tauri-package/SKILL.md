---
name: bcrm-tauri-package
description: 把 BCRM（Rust axum 后端 + Vue 前端）用 Tauri v2 打成便携 exe 并做全表验证的完整规程：构建顺序、数据库落位、启动期 panic 排查、两层验证脚本的用法与脚手架陷阱。当需要重新打包 exe、验证 62 张表的增删改查与全字段查询、或排查「exe 双击没窗口」时使用。
agent_created: true
---

# BCRM 打包与全表验证规程

## 何时用

- 要产出 / 重新产出 `demo/BCRM客户管理系统.exe`
- 要验证「前端能否对 62 张表所有字段增删改查」
- exe 双击一闪而过、窗口不出现
- 前端改了但 exe 里还是旧界面

---

## 一、打包（三步，顺序不可换）

```bash
# ① 前端产物（必须先做）
cd style-lab && "C:/Program Files/nodejs/node.exe" node_modules/vite/bin/vite.js build

# ② 桌面壳（把前端产物 + 后端库编进一个 exe）
cd ../launcher && "C:/Users/Administrator/.cargo/bin/cargo.exe" build --release

# ③ 组装交付目录
#   demo/BCRM客户管理系统.exe   ← 就是 launcher/target/release/bcrm-desktop.exe
#   demo/crm.db                 ← 首次运行自动在同目录建库
```

| 事实 | 值 |
| --- | --- |
| 产物 | `launcher/target/release/bcrm-desktop.exe`，**11.16 MB** |
| 首次耗时 | 约 **9m47s**（~500 crate + `lto=true` + `codegen-units=1`） |
| 增量耗时 | 改 `main.rs` 后重编仍需数分钟（LTO 全量重链接） |
| 工具链 | `cargo 1.98.1`，目标 `stable-x86_64-pc-windows-msvc` |
| 数据库落位 | **exe 同级 `crm.db`**（`db::resolve_db_path()`，便携模式） |

**不要用 `tauri build`** —— 我们只要便携 exe，不要 NSIS 安装包。
Tauri v2 把前端产物编进二进制，所以 release exe 本身就是完整程序。

**`tauri.conf.json` 的 `app.windows` 必须是空数组** —— 窗口由 `main.rs` 建
（要挂 `initialization_script` 注入随机端口），配置里再声明一个同名窗口会直接让程序起不来。详见第二节。

### 为什么顺序不能换

`launcher/build.rs` 注册了 `cargo:rerun-if-changed=../style-lab/dist`，但它**只能触发重编**，
不会替你先把前端构建出来。跳过 ① 的后果是 exe 里嵌的还是上一版界面 ——
这种「改了前端但 exe 没变」最难排查。

---

## 二、最容易踩的坑：启动期 panic

### `there is no reactor running, must be called from the context of a Tokio 1.x runtime`

`launcher/src/main.rs` 里把已 bind 的 std listener 交给 axum，中间要过
`tokio::net::TcpListener::from_std`。**这个函数必须在 Tokio 运行时上下文内调用**，
而 Tauri 的 `.setup(|app| ...)` 回调跑在主线程、**并不在那个运行时里**。

**症状极具迷惑性**：

| 观察到的现象 | 真实原因 |
| --- | --- |
| 双击 exe 一闪而过 | setup 阶段 panic 退出 |
| `bcrm-launcher.log` 只写到「API 地址」就没了，**没有「窗口已创建」** | panic 建窗口之前 |
| `crm.db` 正常生成、端口也分配了 | 这些步骤在 panic 之前 |
| `cargo build` **0 错误** | 运行期 panic，编译器管不着 |

**正确写法**（把转换挪进 async 块）：

```rust
tauri::async_runtime::spawn(async move {
    match tokio::net::TcpListener::from_std(std_listener) {
        Ok(listener) => {
            if let Err(e) = axum::serve(listener, app_router).await {
                eprintln!("axum 退出: {e}");
            }
        }
        Err(e) => eprintln!("转换监听器失败: {e}"),
    }
});
```

listener 是**已经 bind 好**的，转换之前到达的连接由 OS backlog 排队，不会丢请求，
所以不需要额外做「等后端起来」的同步。

### `a webview with label \`main\` already exists`

修完上面那个，**立刻**会撞上这一个 —— 症状**完全一样**，只有 panic 文案不同：

```text
Failed to setup app: error encountered during setup hook:
创建窗口失败: a webview with label `main` already exists
```

原因：`launcher/tauri.conf.json` 的 `app.windows` 里声明了 `label: "main"` 的窗口，
**Tauri 会先按配置自动建窗口、再调 setup 回调**；`main.rs` 的 setup 里又建一个同名的 → 冲突。

**修法：配置里留空数组，窗口完全交给代码。**

```json
"app": { "windows": [], "security": { "csp": null } }
```

不能反过来让配置建窗口：窗口上要挂 `initialization_script` 才能把运行期随机端口注入成
`window.__BCRM_API_BASE__`，配置声明的窗口挂不了脚本 → 前端只能退回 mock 数据。

> **规律**：这两个坑是**串联**的 —— `from_std` panic 时根本走不到建窗口那一步，
> 所以修好第一个才会暴露第二个。**每次修完启动期问题都要重跑一次启动验证，不要只看日志变长了。**

### 铁律：编译通过 ≠ 能跑

**打包类任务必须真启动一次 exe，并检查日志最后一行是不是「窗口已创建」。**
只看 `cargo build` 的 exit code 会漏掉这一类问题。

**优先用 `spawnSync` 同步跑并把 stderr 抓下来** —— `status 101` 是 Rust panic 退出码，
stderr 里有完整 panic 文案，一次就能定位。异步 `spawn` + 读日志会丢掉 stderr，只能靠猜。

```js
// ① 同步启动，直接拿 panic 文案（推荐先做这个）
const { spawnSync } = require('child_process')
const r = spawnSync(exePath, [], { cwd: demoDir, encoding: 'utf8', timeout: 15000 })
console.log('status', r.status, '← 101 就是 panic')   // timeout 到了会 signal SIGTERM
console.log(r.stderr)                                  // panic 原文
console.log(fs.readFileSync(demoDir + '/bcrm-launcher.log', 'utf8'))  // 末行应是「窗口已创建」

// ② 要长期挂着做「查 API / 看窗口」才用 detached
const child = spawn(exePath, [], { detached: true, stdio: 'ignore', cwd: demoDir })
child.unref()
```

> ⚠️ **日志文件是共享的**：`bcrm-launcher.log` 以**追加**方式打开，多个实例共用同一个路径。
> 后启动的实例会把启动横幅追加进去，让前一个实例的「窗口已创建」**看起来像消失了**。
> 判断「窗口建出来没有」别只看日志末行，两点交叉验证：
> ① 有没有 `BCRM客户管理系统.exe` 进程活着；② `API 地址` 那个端口在 `netstat` 里是否 LISTENING。
>
> 实测过：`netstat` 查到 `127.0.0.1:<port>` LISTENING，就说明 axum 已经在 serve ——
> `from_std` 那一步是成功的。

> ⚠️ **进程会被命令结束时回收**：前台 `spawn` 出去的 GUI exe 在 bash 命令结束时会被杀。
> 要做「查 API / 看窗口」的后续验证，得把它放进**后台任务**里跑，再在新命令里读它的日志取端口。

### 端口与前端注入

打包后 `bind("127.0.0.1:0")` 由系统分配空闲端口，经 `initialization_script` 注入成
`window.__BCRM_API_BASE__`，`client.js` 优先读它 → **打包后不用改一行前端代码**。
端口从 `bcrm-launcher.log` 的 `API 地址: http://127.0.0.1:<port>/api/v1` 里读。

---

## 三、两层验证

需求「验证前端能否对数据库所有表项增删改查、查询条件含所有字段单独或联合查询」
需要**两层**证据，缺一不可。

### 第 1 层：后端接口（`tools/_verify_all_tables.mjs`）

```bash
# 前置：8899 隔离副本库上跑一个后端实例（不碰主库）
#   copy 主库时必须连 -wal / -shm 一起、保持同名（WAL 模式）
"C:/Program Files/nodejs/node.exe" tools/_verify_all_tables.mjs
```

覆盖 62 张表 × 建行 / 回读 / **每列单独查询** / **多字段联合查询（逐行核对）** /
count / exists / by / export / order_by / children / 批量增改删 / PUT / PATCH /
按主键删 / 按条件删。**8399 条断言，实测全通过 0 失败 0 跳过**。
报告 `.workbuddy/verify/report.json`。

### 第 2 层：前端界面（`tools/_verify_crud_ui.mjs`）

真实浏览器（CDP 直连 Edge 9222）+ 真实点击，**不直接调 API**。
逐张表：侧边栏进入 → 条件筛选（**逐列驱动界面筛选**）→ 新建 → 编辑 → 删除 →
**重放界面显示的请求串并比对行数**。报告 `.workbuddy/verify/ui-report.json`。

```bash
"C:/Program Files/nodejs/node.exe" tools/_launch-edge.mjs
"C:/Program Files/nodejs/node.exe" tools/browser.mjs tools/_verify_crud_ui.mjs
# 冒烟：UI_TABLES=customer,project 只跑指定表；UI_LIMIT=5 只跑前 5 张
```

前置：8787 后端在跑 + `vite preview` 4173 在跑 + dist 已是最新构建。

---

## 四、验证脚本的三个脚手架陷阱（都踩过）

### 1. 一张表抛出 → 整轮作废

**必须**给主循环的每张表包 `try/catch`，并在**每张表结束时落一次盘**
（`flushReport()`）。否则 62 张表跑到第 2 张挂了，一行结果都不写。

### 2. 空父表会让从表「建不出行」→ 假结论

`visit_record` 在验证库里是空的，于是三张 `visit_*` 从表的必填外键**没有可选项**，
界面上根本建不出行。不处理就会得到「这几张表不支持新增」的**假失败**。

做法：按**拓扑序播种**。每轮只处理当前还空着的表，父表填空了下一轮才能建子表，
多轮自然推进（5 轮足够）。只给「被测表及其传递依赖的父表」补，不动其它表。

```js
const needed = new Set()
const walk = (t) => { if (needed.has(t)) return; needed.add(t)
  for (const ref of Object.values(fkOf[t] ?? {})) walk(ref) }
for (const t of tables) walk(t)     // 传递闭包
for (let round = 0; round < 5; round++) { /* 建空表，父表还空就跳过 */ }
```

### 3. 唯一键重试要覆盖**三类**，少一类就出假失败

「新建行」撞 UNIQUE 时靠换值重试，但**判定哪些唯一键「可换」**必须覆盖三类：

| 唯一键形态 | 例子 | 可换性 | 怎么换 |
| --- | --- | --- | --- |
| 每列都是外键 | `project_c74111.project_id` | ✅ | 换父 id |
| 含多态类型列 | `person_form` / `person_disc` 的 `person_type + person_id` | ✅ | 换一组「类型 + 父 id」 |
| 普通唯一列 | `customer.crm_code` | ❌ | 换父 id 无用，靠值生成器里的**递增序号** |

**第二个坑最深**：`person_type` / `person_id` 在 DDL 里**没有外键约束**
（`person_id` 指向哪张表取决于 `person_type`，DDL 写不出来），所以 `fkOf` 里根本没有它们。

```js
const polyTypeColOf = (uk) => uk.find((k) => POLY[k])          // POLY: person_type/entity_type → 父表映射
const variableUk = uniqKeys.filter(
  (u) => u.length > 0 && (u.every((k) => fkOf[k]) || polyTypeColOf(u))   // ← 少了后半句就漏掉多态表
)
```

只写 `u.every((k) => fkOf[k])` 的后果：`person_form` 被漏掉 → 不重试 → 永远撞 UNIQUE →
报告里出现一条**看起来像产品缺陷的假失败**（「这张表不支持新增」）。
判定方法：用后端接口直接 POST 一行，能建就是脚手架的问题。

**多态组合不能靠 `shift` 递增兜底**：`shift` 是父表 id 列表的下标，
父表只有 1 行时 `ids[shift % 1]` 永远是同一个 id，试 12 次也不变。
正确做法是**把库里已占用的组合全查出来，再挑一个空闲的** —— 结果与父表行数无关：

```js
const freePolyPair = async (uk, skip = 0) => {
  const p = polyIdColOf(uk); if (!p) return null
  const used = new Set((await fetchAll(TABLE)).map((r) => r[p.typeCol] + '#' + r[p.idCol]))
  const free = []
  for (const ty of types) for (const id of await listOf(POLY[p.typeCol][ty]))
    if (!used.has(ty + '#' + String(id))) free.push({ typeCol: p.typeCol, typeVal: String(ty), idVal: String(id) })
  return free[skip] ?? null
}
```

挑出来之后要让**类型列和 id 列都听它的**，否则会被 `PREFER` 里的第一个枚举覆盖回去：
`planValue` 里对 `c.name === polyPick.typeCol` 直接返回 `polyPick.typeVal`，
`polyIdFor` 里直接返回 `polyPick.idVal`。

复验只要两张表，别重跑全量：

```bash
UI_TABLES=person_form,person_disc UI_REPORT=.workbuddy/verify/ui-report-poly.json \
  node tools/browser.mjs tools/_verify_crud_ui.mjs
```

> **报告路径必须可覆盖**（`UI_REPORT`，默认 `ui-report.json`）。
> 否则一次复验就把 62 张表的完整报告盖掉了，想对照都找不回来。

### 顺带：`tools/browser.mjs` 的 CDP 超时

`send()` 超时已从 30s 放宽到 **180s**（`CDP_TIMEOUT_MS` 可覆盖）。
有些 `evalJs` 内部要顺序跑几十次 `await fetch`，表宽 40+ 列（`project` 43 列）时
30s 会被误判成「卡死」→ `Runtime.evaluate 超时`。

---

## 五、后端的两个查询语义坑（写验证断言时必须知道）

### 1. 同名 filter 参数是 **IN** 不是 AND

`filter[id]=1&filter[id]=2` → `id IN (1,2)`。

做「AND 反证」时**必须换一个不同的列**，写成 `filter[a]=真&filter[a]=假` 会得到
「查得到」的假象，看起来像后端 bug：

```js
// 反证条件要落在第三列上，且该列不能是 a/b 中的任何一列
const c3 = nonNull.find((x) => x.col.name !== a.col.name && x.col.name !== b.col.name
                             && absentValue(x.col) != null)
```

### 2. `or` 分组的组号是「组」，不是「更多 OR」

**组内 OR、组间 AND**。所以 `or[0][a]=x&or[1][b]=y` = `(a=x) AND (b=y)`，
不是 `(a=x OR b=y)`。前端「任一满足」模式必须把全部条件塞进 **`or[0]` 同一个组**。

### 3. 枚举/布尔/JSON 列造不出「确定不存在」的值

枚举喂任意值会 400，布尔只有 0/1。这类列上的反证要**跳过而不是编个假值**——
跳过比给个假失败诚实。

---

## 六、验证完必查

```bash
# 后端断言
node -e "const r=require('./.workbuddy/verify/report.json');console.log(r.stats)"
# 界面断言
node -e "const r=require('./.workbuddy/verify/ui-report.json').results;console.log(r.ok,r.failures.length,r.skips.length)"
```

跳过的项要逐条看**性质**：属于「验证手段受限」（如父表数据不够、枚举列无法反证）
可以接受；属于「功能真的没走到」必须补。

---

## 七、文档同步

改了接口行为 / 表结构 / 打包方式后，同步更新 `说明/` 下对应篇章：
01 环境与打包 / 02 技术栈 / 03 接口 / 04 后端设计 / 05 前端设计 / 06 数据库架构 / 07 功能介绍。
`说明/README.md` 是索引。
