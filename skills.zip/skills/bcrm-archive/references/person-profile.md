# 人员画像归档：FORM / DISC / 态度 / ADUR / BI / 情报

> 只要用户描述里出现**人**（客户的人、合作方的人、竞对的人、我们的人），就要主动按本文做画像抽取。
> 四类人员分四张表，画像用「多态表 + `person_type` + `person_id`」挂在任意一类人身上。

## 0. 先定归属（不确认不放行）

| 人物身份 | 主表 | 归属键 | `person_type` |
| --- | --- | --- | --- |
| 客户方人员 | `person` | `customer_id` → `customer.id` | `customer` |
| 合作方人员 | `partner_person` | `coop_entity_id` → `coop_entity.id`（且 `entity_type='partner'`） | `partner` |
| 竞争方人员 | `competitor_person` | `coop_entity_id` → `coop_entity.id`（且 `entity_type='competitor'`） | `competitor` |
| 奇安信内部人员 | `internal_person` | `org_id` → `org.id`（**挂组织树，不挂客户**） | `internal` |

画像表：`person_form`（1:1）、`person_disc`（1:1）、`person_burning_issue`（1:N）、`person_attitude_log`（1:N）、`person_assessment`（1:N）、`person_intel`（1:N）。
后四项都带可选 `project_id`——**一旦项目和人员都有，就顺手带上 project_id**，因为态度、燃眉之急、评估都是"随项目变化"的。

---

## 1. FORM —— 七要素画像（`person_form`）

FORM 是"了解一个人为什么这么做"的七格框架。用户说到相关线索就填，没说到就留空，**不要编**。

| 字段 | 含义 | 识别信号（用户话里出现这些就填） |
| --- | --- | --- |
| `family` | 家庭 | 已婚/孩子几岁/配偶做什么/父母身体/老家 |
| `occupation` | 职业 | 干了多少年/从哪个岗位上来/分管什么/专业出身 |
| `recreation` | 娱乐/兴趣 | 高尔夫/跑步/喝茶/钓鱼/球赛/收藏/摄影 |
| `motivation` | 动机/驱动力 | 想升职/想调岗/怕出事/想立项目/要政绩/为退休铺路 |
| `career_bg` | 职业背景 | 技术/销售/财务出身（枚举：`技术` / `销售` / `财务`） |
| `kpi_pressure` | KPI 压力 | 考核什么/被谁考核/今年的硬指标/安全事件问责 |
| `personality` | 性格 | 强势/谨慎/话少/爱面子/技术控/讲流程 |
| `concern` | 关注点 | 最在意什么（合规、成本、稳定、不被领导批） |
| `supplementary` | 补充 | 其他有用细节 |

> 抽 FORM 的最高价值点是 **`motivation` + `kpi_pressure`**——这两项直接喂给 C2（拍板人燃眉之急）。
> 用户只说了"李主任抱怨今年被审计追得紧" → `kpi_pressure='被审计/合规问责压力大'`、`motivation='怕出事、求稳'`，同时可生成 `person_burning_issue`。

---

## 2. DISC —— 四维打分（`person_disc`）

对 **D/I/S/C 各打 1–5 分**，取最高者为 `dominant`。分数据行为证据推，不凭空给。

| 维度 | 中文 | 高分行为特征 | 低分特征 |
| --- | --- | --- | --- |
| **D** 支配 | 支配型 | 直接下结论、问结果、语速快、不接受废话、拍板果断 | 反复请示、回避决定 |
| **I** 影响 | 影响型 | 健谈、爱讲愿景、在意面子排场、喜欢被认可、拉关系 | 沉默、只谈事实 |
| **S** 稳健 | 稳健型 | 慢热、重关系、怕变化、要稳定、从众 | 频繁跳槽式换方案、激进 |
| **C** 服从 | 服从型 | 要数据、要文档、抠细节、讲流程合规、质疑参数 | 凭感觉拍板 |

| 字段 | 说明 |
| --- | --- |
| `score_d` ~ `score_c` | 1–5 整数 |
| `dominant` | 最高维度的中文名（`支配型` / `影响型` / `稳健型` / `服从型`），并列时取**决策影响更大**的那个并注明 |
| `behavior_evidence` | **必填**：从用户原话里引一句作为证据，如"他说'方案先放放，你给我个报价'" |
| `note` | 备注 |

> 只给了"这人很强势、直接问多少钱" → D=4，S/C 给 2，dominant=支配型，evidence 引用原话。
> **一次对话里没足够信息就只写对方能确认的维度，或干脆不写 DISC，只在待确认问题里提一句"要不要补 DISC 打分"。**

---

## 3. 态度标尺（枚举 `attitude`）

`X` 反对 · `-` 不支持 · `=` 中立 · `+` 支持 · `⭐` 导师（内线/可共谋）

- **`⭐` 的门槛很高**：必须同时满足"明确支持 + 愿意/已经一起策划 + 能提供内部信息"。只是"关系好、请吃过饭"→ 最多 `+`。
- 态度是**随项目变化**的：客户人员写 `project_member.attitude`；合作/竞争方人员写 `partner_person_project_rel` / `competitor_person_project_rel` 或主表的 `attitude`。
- 态度变化要**另起一条** `person_attitude_log`（`eval_date` / `attitude` / `evidence` / `target_attitude` / `upgrade_path`），不要直接覆盖旧值——历史轨迹本身就是情报。

### ADUR 角色（客户人员，`project_member.adur_role` / `visit_object.adur_role`）

| 代号 | 含义 |
| --- | --- |
| **A** | 决定人 Approver（签字/最终批准，常在上级单位） |
| **D** | 拍板人 Decider（真正说了算的人） |
| **U** | 使用者 User |
| **R** | 推荐人 Recommender（写参数/定标段的人） |

> 判断口诀：**A 签不签、D 说不说、U 用不用、R 推不推**。
> "他能拍板" → D；"他签字但什么都听上头的" → A；"他跟厂家关系好、参数是他写的" → R。

---

## 4. 燃眉之急 BI（`person_burning_issue`，1:N）

三判据（都是 0/1）：

| 字段 | 判据 | 为 1 的条件 |
| --- | --- | --- |
| `is_personal` | 是否**他个人**的 | 影响他个人（KPI、升迁、背锅、退休前政绩），而不是"公司的事" |
| `is_immediate` | 是否**当下**的 | 有明确时间压力（本季度、上级检查在即） |
| `is_certain` | 是否**确定**的 | 已是既成事实/已下发文件，而不是"可能会" |

> **三判据全为 1 = 真燃眉之急**，是 C2 打 5 分、也是最好的切入点。
> 任一为 0 都要在 `remark` 里写清为什么，并把它放进"待确认问题"。
> `our_solution` 写我们怎么解决，`verify_method` 写怎么交叉验证（这一项不填等于没验证）。

---

## 5. 评估与情报

**`person_assessment`**（+/⭐ 与可转化性）：`plus_features` / `star_features` 存 JSON 数组（满足的特征清单）、`rating`、`evidence`、`transformability`（可转化性）、`intel_value`（情报价值）、`risk`。
**`person_intel`**：`content`（情报内容）/ `source`（本人/转述）/ `credibility`（高/中/低）/ `application`（我方怎么用）/ `verify_result`（属实/存疑/证伪）。

> 用户说"他说对手这周报了 80 万" → `person_intel`，`content='对手报价约80万'`、`source='本人'`、`verify_result='存疑'`（等交叉验证）。
> **转述 vs 本人**一定要分清：转述的可信度默认降一档。

---

## 6. 幂等与更新规则

1. 先 `crm.mjs find-any <姓名>` 查是否已存在 → 存在则 **UPDATE 补字段**，不要重复 INSERT。
2. `person_form` / `person_disc` 有 `UNIQUE(person_type, person_id)` → 用 `INSERT ... ON CONFLICT(person_type, person_id) DO UPDATE SET ...`。
3. 只更新"用户这次提供了信息"的列，**不要用空值覆盖已有内容**（UPDATE 只写 SET 里出现的列）。
4. 人员的 `parent_id`（汇报关系）只在用户明确说了上下级时才写；同一客户最多 5 级。
