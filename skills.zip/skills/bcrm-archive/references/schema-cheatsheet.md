# 库结构速查（61 表 / 838 列）

> 唯一权威来源：`backend/resources/schema.json`（由 `tools/build_api_docs.py` 从 DDL 生成）。
> **本文件只是索引，写 SQL 前用 `crm.mjs schema <表名>` 确认列名与枚举，不要凭记忆写。**
> 类型约定：金额 `REAL` 单位**万元**；日期 `TEXT` ISO8601；布尔 `INTEGER` 0/1；枚举 `TEXT` + CHECK；JSON 列 `TEXT`。

---

## 一、61 张表分组总览

### A. 客户域（17）
| 表 | 用途 | 挂谁 |
| --- | --- | --- |
| `customer` | 客户主表 | — |
| `customer_relation` | 关联客户（上级/下属/平级/合作） | `customer_id` |
| `customer_profile` | 企业画像五大维度（1:1） | `customer_id` UNIQUE |
| `customer_exec_meeting` | 与客户高层互动 | `customer_id` |
| `customer_budget` / `customer_budget_detail` | 年度预算 / 预算构成明细 | `customer_id` |
| `customer_sales_data` | 营销数据与我司销售分析（年度） | `customer_id` |
| `customer_tender` | 标讯信息（年度） | `customer_id` |
| `customer_purchase` | 过往采购（我司+友商） | `customer_id` |
| `customer_foreign_product` | 国外产品摸底（国产替代线索） | `customer_id` |
| `customer_need` | 客户需求 | `customer_id` |
| `customer_opportunity` | 线索/商机 | `customer_id` |
| `customer_competition` | 客户侧竞争情况 | `customer_id` |
| `customer_target` | 任务目标 | `customer_id` |
| `customer_perf_dashboard` | 业绩仪表盘 Q1–Q4 | `customer_id` |
| `customer_team` | 专属团队（客户组织/项目组织） | `customer_id`（+`project_id`） |
| `customer_action_plan` | 五+一工程行动计划 | `customer_id` |

### B. 人员域（11）
`person`（客户人员）· `partner_person` · `competitor_person` · `internal_person` · `org`（我司组织树）
· `person_form` · `person_disc` · `person_burning_issue` · `person_attitude_log` · `person_assessment` · `person_intel`

### C. 项目域（4）
`project` · `project_member`（人员↔项目，带 ADUR/态度） · `project_c74111`（1:1） · `project_action_plan`（开门七件事）

### D. 合作竞争域（5）
`coop_entity`（实体统一表，`entity_type` 区分） · `coop_entity_project_rel`（实体级）
· `partner_person_project_rel` / `competitor_person_project_rel`（人员级） · `entity_history`

### E. 销售分析域（13，全部多态 `entity_type`+`entity_id`）
`entsales_perf` · `_product` · `_market` · `_distribution` · `_channel` · `_pricing` · `_customer_share`
· `_tender` · `_confrontation` · `_tactic` · `_benchmark` · `_plan` · `_source`

### F. 拜访行动域（4）
`visit_record` · `visit_our_staff`（我方人员→`internal_person`） · `visit_object`（客户人员） · `visit_action_item`（行动项）

### G. Dashboard / 动态域（7）
`news_item` · `customer_news` · `dashboard_update_log` · `daily_plan` · `daily_todo` · `dashboard_note` · `dashboard_shortcut`

---

## 二、归属关系总表（回答"这东西挂哪儿"）

| 对象 | 归属键 | 基数 | 不确定时怎么办 |
| --- | --- | --- | --- |
| 客户人员 `person` | `customer_id` | 多对一 | **问**"这位是哪个单位的" |
| 合作方人员 `partner_person` | `coop_entity_id` | 多对一 | **问**"他是合作方还是竞争方的人、哪家公司" |
| 竞争方人员 `competitor_person` | `coop_entity_id` | 多对一 | 同上 |
| 内部人员 `internal_person` | `org_id` | 多对一 | **问**"他在我们哪个军团/部门" |
| 项目 `project` | `customer_id`（**仅主客户**） | 多对一 | **问**"这个项目是哪个客户的" |
| 客户人员 ↔ 项目 | `project_member`（`project_id`+`person_id` UNIQUE） | 多对多 | ADUR/态度随项目，**问**"他在这个项目里什么角色" |
| 合作/竞争方实体 ↔ 项目 | `coop_entity_project_rel` | 多对多 | **问**"这家在这项目里是合作还是竞争" |
| 合作/竞争方人员 ↔ 项目 | `partner_person_project_rel` / `competitor_person_project_rel` | 多对多 | 同上 |
| 客户 ↔ 关联客户 | `customer_relation`（`relation_type`） | 多对多 | **问**"是上级、下属、平级还是合作单位" |
| 拜访 ↔ 我方人员 | `visit_our_staff` → `internal_person` | 多对多 | **问**"我们这边谁去了" |
| 拜访 ↔ 客户人员 | `visit_object` → `person` | 一对多 | 同上 |
| 人员 ↔ FORM/DISC/BI/态度/评估/情报 | `person_type` + `person_id`（+可选 `project_id`） | 1:1 / 1:N | **问**"这个人属于哪一类（客户/合作/竞争/内部）" |
| 销售分析 `entsales_*` | `entity_type` + `entity_id` → `coop_entity.id` | 1:N | **问**"这些数字是说哪家公司的" |

---

## 三、枚举字典（高频）

```
category            主客户 | 关联客户
level               （项目）P1 | P2 | P3 | P4          ← customer.level 是自由文本"TOP1000大客户"等，别混
attitude            X | - | = | + | ⭐
credibility         高 | 中 | 低
info_type           线索 | 商机 | （项目表另有）项目
sub_type / opp_type / purchase_type   框架 | 续采 | 创新 | 定制 | 标品
project_mode        直签 | 渠道 | 项目合作
tender_mode         公开招标 | 单一来源采购 | 询价 | 邀请招标 | 竞争性谈判 | 磋商
purchase_cycle      前期 | 中期 | 后期
competition         绝对优势 | 相对优势 | 相对劣势 | 绝对劣势
commitment          可承诺 | 可争取 | 可参与 | 不可承诺
prediction          可争取 | 可参与 | 可承诺
entity_type         partner | competitor | both
company_type        代理商 | 集成商 | 原厂 | 渠道 | 厂商 | 其他
relation_nature     合作 | 竞争 | 竞合
relation_status     热 | 温 | 冷
decision_mode       诸侯制 | 集权制
decision_power      拍板 | 影响 | 执行
decision_role       拍板 | 协调 | 支撑 | 执行
career_bg           技术 | 销售 | 财务
intel_ability       强 | 中 | 弱
verify_result       属实 | 存疑 | 证伪
method              （拜访方式）面访 | 电话 | 视频
priority            高 | 中 | 低
metric              订单额 | 订单毛利 | 毛利率
engine_type         关系提升 | 安全改造 | 质量提升 | 服务改善 | 共创创新 | 其他
scope               （customer_team）客户组织 | 项目组织
category            （news_item）行业与市场 | 政策法规 | 攻防事件/漏洞 | AI安全
dim_type            行业 | 区域
person_type         customer | partner | competitor | internal
is_new / is_ours / is_mentor / is_personal / is_immediate / is_certain / p3_star / p4_star / key_star / bu_leader_involved / exclusive_promise   → 0 | 1
```

> ⚠️ `project.scope` / `customer_opportunity.scope`（部署/服务范围）和 `org.level`（层级整数）、`customer.level`、`*.method`（手段方法）都是**自由文本**，没有枚举约束，别套错枚举。

---

## 四、唯一键与冲突处理（10 处）

| 表 | 唯一键 | 幂等写法 |
| --- | --- | --- |
| `customer` | `crm_code` | 先按 `name`/`crm_code` 查，有则 UPDATE |
| `customer_profile` | `customer_id` | `ON CONFLICT(customer_id) DO UPDATE SET ...` |
| `project_c74111` | `project_id` | `ON CONFLICT(project_id) DO UPDATE SET ...` |
| `project_member` | `(project_id, person_id)` | `ON CONFLICT(project_id, person_id) DO UPDATE SET ...` |
| `person_form` / `person_disc` | `(person_type, person_id)` | 同上 |
| `coop_entity_project_rel` | `(coop_entity_id, project_id)` | 同上 |
| `partner_person_project_rel` | `(partner_person_id, project_id)` | 同上 |
| `competitor_person_project_rel` | `(competitor_person_id, project_id)` | 同上 |
| `visit_our_staff` | `(visit_id, internal_person_id)` | 同上 |

---

## 五、常用查询模板

```bash
# 反查归属（最重要的一条：任何名字先进这里）
node crm.mjs find-any 李四

# 找 ID
node crm.mjs q "SELECT id, name, crm_code FROM customer WHERE name LIKE '%丙能源%'"
node crm.mjs q "SELECT id, name FROM project WHERE customer_id = 3"

# 查某人参与的全部项目及角色
node crm.mjs q "SELECT p.name AS 人名, pm.adur_role, pm.attitude, pr.name AS 项目 FROM person p JOIN project_member pm ON pm.person_id=p.id JOIN project pr ON pr.id=pm.project_id WHERE p.name='李四'"

# 查某项目的 C74111 现状
node crm.mjs q "SELECT total_score, win_rate, competition, commitment FROM project_c74111 WHERE project_id = 1"

# 查某客户的关键人态度全景
node crm.mjs q "SELECT p.name, p.title, pm.adur_role, pm.attitude FROM person p LEFT JOIN project_member pm ON pm.person_id=p.id WHERE p.customer_id = 3"
```

**写 SQL 时的取 ID 惯例**：
- 刚 INSERT 过、**且只有一条子表** → `last_insert_rowid()`
- 一个主体带**多条子表** → `(SELECT MAX(id) FROM visit_record WHERE customer_id = <id>)`
  ⚠️ `last_insert_rowid()` 只在下一条语句里可靠，多子表场景下会被覆盖，必须换成 MAX 写法（详见 `playbooks.md` 剧本 1）
- 已存在 → `(SELECT id FROM customer WHERE name='丙能源' ORDER BY id DESC LIMIT 1)`
- 都不确定 → 先用 `find-any` 查出来，把**原始数字 ID 写进 SQL**，让用户在草案里看到具体挂在谁身上

---

## 六、数据库文件与运行环境

- 数据库文件位置按优先级解析：`--db` 参数 / `BCRM_DB` 环境变量 → **正在运行的后端服务**（`GET http://127.0.0.1:8787/api/v1/meta/health` 返回的 `data.db_path`）→ `backend/data/crm.db` → `backend/data/smoke.db` → `%APPDATA%/Bcrm/crm.db`。
- 后端是 Rust axum，单连接 + Mutex + WAL。脚本用 `PRAGMA busy_timeout=8000` 与之共存；**写入尽量短事务，一次一批**。
- ⚠️ 库是 **WAL 模式**。如果为了试验要复制一份库，**必须把 `-wal` / `-shm` 一起复制并改成同名**（`cp x.db y.db && cp x.db-wal y.db-wal && cp x.db-shm y.db-shm`）。只复制 `.db` 会丢掉还在 WAL 里没 checkpoint 的数据，出现"客户明明存在却报外键失败"这种假故障。
- Node 需要 **≥ 22**（用 `node:sqlite`）。优先 Node 24（无实验性警告）：`C:\Program Files\nodejs\node.exe`；回退 managed Node 22：`C:\Users\Administrator\.workbuddy\binaries\node\versions\22.22.2\node.exe`。
