# 六类输入的归档剧本

每个剧本 = **必问项 → 能推断项 → 涉及表 → SQL 骨架 → 顺带产出**。
所有剧本共同遵守：先 `find-any` 反查 → 存在则 UPDATE 补字段 → 不存在才 INSERT → 归属不明**必须问**。

---

## 剧本 1：拜访记录（最高频）

**识别信号**：今天/昨天去了某客户、见了谁、聊了什么、答应了什么、下次干嘛。

### 必问（缺一个都不能出草案）
| 缺口 | 问法 |
| --- | --- |
| 哪家客户 | "这次拜访的是哪家客户？" |
| 拜访日期 | "哪天去的？（`visit_record.visit_date` 是必填）" |
| 我方谁去了 | "我们这边谁一起去的？"（要落到 `visit_our_staff` → `internal_person`，需要人+组织） |
| 客户方见了谁 | "客户方见了哪几位？"（落到 `visit_object` → `person`） |

### 可推断
`method`（"去了他们公司"→`面访`；"打了个电话"→`电话`；"开了个视频会"→`视频`）、`visit_time`、`place`、`result`。

### 涉及表
`visit_record` → `visit_object`（1:N） → `visit_our_staff`（1:N，指向 `internal_person`） → `visit_action_item`（1:N）

### SQL 骨架
```sql
-- ① 主体
INSERT INTO visit_record (customer_id, project_id, visit_date, visit_time, place, method,
  our_participants, client_participants, recorder, purpose, goal_smart, agenda, process_record,
  needs_pain, competition_intel, client_feedback, client_commit, our_commit, result,
  short_todo, mid_follow, next_visit, resource_need, review_good, review_bad, key_harvest, next_strategy)
VALUES (<customer_id>, <project_id 或 NULL>, '2026-09-14', '14:00', '客户总部', '面访',
  '张三,李四', '王主任,刘处长', '张三', '...', '...', '...', '...',
  '...', '...', '...', '...', '...', '...',
  '...', '...', '...', '...', '...', '...', '...', '...');

-- ②③④ 子表统一用这一句取 visit_id：
--      (SELECT MAX(id) FROM visit_record WHERE customer_id = <customer_id>)
--      ⚠️ 千万不要在这里用 last_insert_rowid()——它会被下面每一条 INSERT 覆盖掉，
--         第 3 条子表就会把 visit_object 的 id 当成 visit_id 写进去。
INSERT INTO visit_object (visit_id, person_id, adur_role, attitude, disc, burning_issue, remark)
VALUES ((SELECT MAX(id) FROM visit_record WHERE customer_id = <customer_id>), <person_id>, 'D', '=', NULL, '...', NULL);

INSERT INTO visit_object (visit_id, person_id, adur_role, attitude, disc, burning_issue, remark)
VALUES ((SELECT MAX(id) FROM visit_record WHERE customer_id = <customer_id>), <person_id2>, 'R', '+', NULL, NULL, NULL);

INSERT INTO visit_our_staff (visit_id, internal_person_id, role, remark)
VALUES ((SELECT MAX(id) FROM visit_record WHERE customer_id = <customer_id>), <internal_person_id>, '主讲', NULL);

INSERT INTO visit_action_item (visit_id, seq, action, owner, deliverable, due_time, priority, status, background, method, expected_effect, risk)
VALUES ((SELECT MAX(id) FROM visit_record WHERE customer_id = <customer_id>), 1, '输出方案初稿', '张三', '方案文档', '2026-09-19', '高', '待办', '...', '...', '...', '...');
```
> `last_insert_rowid()` 只在**紧跟 INSERT 的下一条语句**里可靠。一旦一条主体要带多个子表，就必须换成本条注释里的 `MAX(id)` 写法。

### 顺带产出（发现即归档，不要漏）
| 文中出现 | 归档到 |
| --- | --- |
| 客户说"我们今年被审计追得紧" | `person_burning_issue`（三判据尽量问清） |
| 提到对手报价/动作 | `person_intel` + `visit_record.competition_intel` |
| 客户某人态度有变化 | `person_attitude_log`（**新增一条**，不覆盖） |
| 冒出一个新线索/商机 | `customer_opportunity` |
| 客户组织/预算/技术环境的新描述 | `customer_profile` 对应维度 |
| 提到某个项目 | 触发**剧本 4**（含 C74111 评估） |

---

## 剧本 2：客户信息

**识别信号**：讲某家客户的规模、行业、业务、组织、预算、历史采购、竞争格局。

### 必问
- "这是新客户还是库里已有的？"（先 `find-any`，若返回多条同名 → 列出来让用户选）
- 新建时必问 **`crm_code`**（唯一，必填 NOT NULL）与 **`category`**（主客户 / 关联客户）
- 提到关联客户/上级单位 → **问关系类型**（`上级`/`下属`/`平级`/`合作`）

### 涉及表
`customer` · `customer_profile`（1:1） · `customer_relation` · `customer_budget` · `customer_purchase` · `customer_competition` · `customer_team` · `customer_foreign_product`

### SQL 骨架
```sql
INSERT INTO customer (crm_code, name, category, level, army_region, industry, account_manager,
  created_date, data_source, func, core_business, serve_object, scale, staff_scale, output_3y,
  dev_plan, policy_impact, biz_trend, demand_factors, influence, superior_unit, co_unit,
  support_unit, key_scenes, app_systems, network_env, security_status, tags, remark)
VALUES ('S100', '某某银行', '主客户', 'TOP1000大客户', '金融大区', '金融', '张三',
  '2026-09-14', '拜访口述', ...);

INSERT INTO customer_profile (customer_id, strength_scale, equity_structure, lifecycle, niche,
  strategy_pain, tech_decision, purchase_feature, supplier_structure, performance_relation,
  coop_barrier, swot, remark)
VALUES (<customer_id>, ...)
ON CONFLICT(customer_id) DO UPDATE SET strength_scale=excluded.strength_scale, ...;
```

> `customer.level` 是自由文本（如 `TOP1000大客户`），**不要**写成 P1–P4（那是 `project.level`）。

---

## 剧本 3：人员信息

**识别信号**：描述某个具体的人——姓名、职务、性格、态度、家庭、KPI。

**见 `references/person-profile.md`**，要点：
1. **第一步永远是问归属**：客户的人 / 合作方的人 / 竞争方的人 / 我们的人。
2. 归属定了 → 写主表（`person` / `partner_person` / `competitor_person` / `internal_person`）。
3. 顺带做画像：FORM（`person_form`）、DISC（`person_disc`）、态度（`person_attitude_log`）、燃眉之急（`person_burning_issue`）。
4. 谈到具体项目 → 补 `project_member`（客户人员）或人员级项目关系表（合作/竞争方人员）。

---

## 剧本 4：项目信息（**必触发 C74111 评估**）

**识别信号**：某个具体的采购/建设项目、预算、招标方式、竞争对手、进度、打法。

### 必问
| 缺口 | 问法 |
| --- | --- |
| 属于哪个客户 | "这个项目是哪个客户的？"（`project.customer_id` 必填，且只挂**主客户**） |
| 是线索/商机/项目 | "目前算线索、商机，还是已经立项的项目？"（`info_type`） |
| 项目金额与预算 | "预算大概多少？（单位万元）"——**用户说的金额一律先确认是不是"万元"** |
| 项目级别 | 没说的话按 `P2` 暂存并标注"级别待定" |

### 涉及表
`project` · `project_c74111`（**同步生成**） · `project_action_plan` · `project_member` · `coop_entity` / `coop_entity_project_rel` · `customer_competition`

### SQL 骨架
```sql
INSERT INTO project (customer_id, name, project_type, level, info_type, sub_type, project_mode,
  tender_mode, background, time_phase, purchase_mode, purchase_cycle, budget, sec_budget,
  exp_budget, act_budget, amount, c74111_amount, gross_margin, exp_order_time, risk_level, risk,
  next_plan, market_status, tech_status, scope, products, services, tech_support, ucv,
  win_score, strategy, competition, commitment, swot, other_note)
VALUES (<customer_id>, '某行数据安全平台', '数据安全', 'P2', '商机', '创新', '直签',
  '公开招标', ...);

-- C74111 诊断（与项目 1:1，跟项目同批写入）
INSERT INTO project_c74111 (project_id, c1_score, c1_note, ..., c7_score, c7_note,
  p1_score, p1_flags, p2_score, p2_flags, p3_score, p3_star, p4_score, p4_star,
  key_score, key_star, clear_score, priority_score, key_total, total_score, win_rate,
  competition, commitment, strategy, action_plan)
VALUES ((SELECT MAX(id) FROM project WHERE customer_id = <customer_id>), ...)
ON CONFLICT(project_id) DO UPDATE SET c1_score=excluded.c1_score, ...;
```
> `project_id` 同样**别用 `last_insert_rowid()`**（中间可能夹着 `coop_entity_project_rel` 等插入），一律用 `(SELECT MAX(id) FROM project WHERE customer_id = <customer_id>)`。
> 若项目已存在，`ON CONFLICT(project_id) DO UPDATE SET ...` 只更新本次提到的那几项分与 note，**不要把用户没提的项清零**。

### C74111 自动评估的呈现方式（每次必做）
1. 逐项给分 + 一句依据（依据来自用户原话或库内已有记录）；
2. 汇总：`clear_score` / `priority_score` / `key_total` / `total_score` / `win_rate`；
3. 判定：`competition` + `commitment`；
4. **明确标出哪些分是"没证据保守给低分"的**，并把它们转成待确认问题；
5. 若本次信息不足以打分（例如只有一个项目名），**不要硬凑分**——告诉用户"资料不足，暂不打分"，只建档，并在草案里列出"补齐这些信息后就能出诊断"的清单。

> 详细打分口径见 `references/c74111-scoring.md`。

---

## 剧本 5：合作 / 竞争方

**识别信号**：提到某家公司与我们合作、代理、竞争、报价。

### 必问
- "这家是合作方、竞争方，还是又合作又竞争（竞合）？" → `entity_type` = `partner` / `competitor` / `both`
- "有没有唯一/独家承诺？" → `exclusive_promise` 0/1
- 提到具体项目 → **问**实体级还是人员级关系（往往两者都要）→ `coop_entity_project_rel` + 人员级关系表
- 提到这家公司的人 → 走剧本 3，`person_type='partner'/'competitor'`

### 涉及表
`coop_entity` · `coop_entity_project_rel` · `partner_person_project_rel` / `competitor_person_project_rel` · `entity_history` · `entsales_*`

### SQL 骨架
```sql
INSERT INTO coop_entity (entity_type, name, company_type, headquarters, equity_bg, listing,
  overall_relation, competition_situation, exclusive_promise, info_source, credibility,
  q_company, q_insider, q_strategy, product_matrix, market_share, channel_strategy, agent_system,
  price_band, business_tactics, ecosystem, value_prop, product_rank, advantage, weakness,
  our_advantage, our_weakness, fab_talk, remark)
VALUES ('competitor', '某安全厂商', '原厂', '北京', ..., 0, '同行', ...);

INSERT INTO coop_entity_project_rel (coop_entity_id, project_id, our_liaison, their_liaison,
  relation_nature, relation_status, diff_points, their_tactic, our_strategy, result, remark)
VALUES (<coop_entity_id>, <project_id>, '张三', '对方销售', '竞争', '热', ...)
ON CONFLICT(coop_entity_id, project_id) DO UPDATE SET ...;
```

> **合作方与竞争方共用 `coop_entity` 一张表**，靠 `entity_type` 区分；但人员分表（`partner_person` / `competitor_person`）。
> 一家公司同时是合作方又是竞争方 → `entity_type='both'`，同时可出现在 `partner_person` 与 `competitor_person`。

---

## 剧本 6：情报与动态

**识别信号**：听到的消息、对手动作、报价、标底、客户动向、行业新闻。

| 类型 | 归档到 |
| --- | --- |
| 某个人的一手/转述消息 | `person_intel`（`source` 分清"本人/转述"；转述可信度降一档；`verify_result` 默认 `存疑`） |
| 拜访中听到的竞对动作 | `visit_record.competition_intel` + `person_intel` |
| 某家合作/竞争方与客户的交锋 | `entity_history` + `entsales_confrontation` |
| 客户自身动态（人事/项目/舆情） | `customer_news`（`is_new`=1 增量） |
| 行业/AI 安全新闻 | `news_item`（`category` 五选一） |
| 我自己的待办/灵感 | `daily_todo` / `daily_plan` / `dashboard_note` |

> 情报**默认存疑**，禁止把转述当事实。`verify_method` / `verify_result` 至少要填一个，否则提醒用户"这条没验证路径"。

---

## 通用：一次口述常常跨多个剧本

例如："今天去丙能源见了信息中心李主任，他说审计追得紧，对手报了80万，我们答应周五给方案，还提到他们在搞数据安全平台，预算300万，是王总拍板。"

拆解结果：
1. 剧本 1 拜访记录 → `visit_record` + `visit_object`（李主任）+ `visit_our_staff` + `visit_action_item`（周五给方案）
2. 剧本 3 人员 → 李主任（`person` + FORM 线索 + 燃眉之急）；王总（`person`，ADUR=D，**归属可能是同一客户，需确认**）
3. 剧本 6 情报 → `person_intel`（对手报价 80 万，转述，存疑）
4. 剧本 4 项目 → 数据安全平台（**触发 C74111**）
5. 剧本 2 → `customer_budget`（300 万预算，**确认是"万元"**）

→ 输出时按这个顺序组织操作清单，用户一眼能看懂"我这段大白话变成了 5 组数据"。
