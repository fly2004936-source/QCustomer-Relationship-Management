#!/usr/bin/env node
/**
 * crm.mjs —— 客户管理系统（Bcrm）归档工具
 *
 * 只做四件事，全部围绕「先看后写、用户确认才落库」：
 *   1. 定位数据库（自动跟随正在运行的后端服务）
 *   2. 查表结构（来自 backend/resources/schema.json 白名单，绝不猜列名）
 *   3. 反查归属（客户 / 人员 / 项目 / 合作竞争方 / 组织，用于"这个人属于谁"）
 *   4. 校验并执行 SQL（静态校验 → 事务内 dry-run → 用户确认后 apply）
 *
 * 用法：
 *   node crm.mjs dbinfo
 *   node crm.mjs tables
 *   node crm.mjs schema <table>
 *   node crm.mjs enums [列名]
 *   node crm.mjs find <table> [--like 关键字] [--col 列名] [--limit 20] [--json]
 *   node crm.mjs q "<SELECT ...>"            # 只读查询
 *   node crm.mjs find-any <关键字>            # 全库反查归属
 *   node crm.mjs check <file.sql>            # 静态校验，只读不动库
 *   node crm.mjs apply <file.sql> [--dry-run]  # 事务执行；--dry-run 执行后回滚
 *
 * 环境变量：
 *   BCRM_ROOT  项目根目录（含 backend/resources/schema.json）
 *   BCRM_DB    直接指定 .db 文件路径，优先级最高
 *   BCRM_API   后端地址，默认 http://127.0.0.1:8787
 */

import fs from 'node:fs';
import path from 'node:path';
import { execFileSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import { DatabaseSync } from 'node:sqlite';

const SCRIPT_DIR = path.dirname(fileURLToPath(import.meta.url));
const API_BASE = (process.env.BCRM_API || 'http://127.0.0.1:8787').replace(/\/+$/, '');

/* ============================ 1. 定位项目与 schema ============================ */

function findRoot() {
  const tried = [];
  const candidates = [];
  if (process.env.BCRM_ROOT) candidates.push(process.env.BCRM_ROOT);
  // 本文件通常位于 <root>/.workbuddy/skills/bcrm-archive/scripts/
  candidates.push(path.resolve(SCRIPT_DIR, '..', '..', '..', '..'));
  candidates.push(process.cwd());

  for (const start of candidates) {
    let dir = path.resolve(start);
    for (let i = 0; i < 10; i += 1) {
      if (fs.existsSync(path.join(dir, 'backend', 'resources', 'schema.json'))) return dir;
      tried.push(dir);
      const up = path.dirname(dir);
      if (up === dir) break;
      dir = up;
    }
  }
  fail(`找不到项目根目录（未能定位 backend/resources/schema.json）。\n已尝试：\n  ${tried.join('\n  ')}\n可设置环境变量 BCRM_ROOT 指定项目根目录。`);
}

const ROOT = findRoot();
const SCHEMA_PATH = path.join(ROOT, 'backend', 'resources', 'schema.json');
const SCHEMA = JSON.parse(fs.readFileSync(SCHEMA_PATH, 'utf8'));

/** 表名 -> 表定义 */
const TABLES = new Map();
for (const t of SCHEMA.tables) TABLES.set(t.name, t);
/** 列名 -> 该列上出现的所有枚举取值（全局 enums 优先） */
const GLOBAL_ENUMS = SCHEMA.enums || {};

function fail(msg) {
  console.error(`✖ ${msg}`);
  process.exit(1);
}
function tableDef(name) {
  const key = String(name || '').replace(/["'`\[\]]/g, '').trim();
  const def = TABLES.get(key);
  if (!def) fail(`表 "${key}" 不在白名单内。库里共 ${TABLES.size} 张表，用 \`crm.mjs tables\` 查看。`);
  return def;
}
function colMap(def) {
  const m = new Map();
  for (const c of def.columns) m.set(c.name, c);
  return m;
}
/**
 * 少数列在 DDL 里写了 CHECK 但元数据没把枚举挂到列上，这里显式补齐。
 * 只按 (表, 列) 精确匹配 —— 绝不按列名猜，否则 customer.level(客户级别) 会被
 * 误判成 project.level(P1-P4) 的枚举。
 */
const ENUM_FALLBACK = {
  'internal_person.career_bg': 'career_bg',
  'person_form.career_bg': 'career_bg',
  'customer_opportunity.project_mode': 'project_mode',
};

/** 某列的枚举取值：以列自带 enum 为准，其次查显式补齐表 */
function enumOf(tableName, colName, colDef) {
  if (colDef && Array.isArray(colDef.enum) && colDef.enum.length) return colDef.enum;
  const fb = ENUM_FALLBACK[`${tableName}.${colName}`];
  if (fb && Array.isArray(GLOBAL_ENUMS[fb]) && GLOBAL_ENUMS[fb].length) return GLOBAL_ENUMS[fb];
  return null;
}

/* ============================ 2. 定位数据库文件 ============================ */

function resolveDbPath(cliDb) {
  const explicit = cliDb || process.env.BCRM_DB;
  if (explicit) {
    const p = path.resolve(explicit);
    if (!fs.existsSync(p)) fail(`指定的数据库文件不存在：${p}`);
    return { file: p, source: '命令行/环境变量指定' };
  }

  // a) 跟随正在运行的后端服务（最可靠：写的一定是它正在用的那个库）
  const fromServer = probeServer();
  if (fromServer) return fromServer;

  // b) 常见位置
  const cands = [
    path.join(ROOT, 'backend', 'data', 'crm.db'),
    path.join(ROOT, 'backend', 'data', 'smoke.db'),
    path.join(ROOT, 'data', 'crm.db'),
    path.join(process.env.APPDATA || '', 'Bcrm', 'crm.db'),
  ].filter(Boolean);
  for (const p of cands) {
    if (fs.existsSync(p)) return { file: p, source: '本地扫描命中' };
  }
  fail(`找不到数据库文件。\n候选位置：\n  ${cands.join('\n  ')}\n可设置环境变量 BCRM_DB 指定。`);
}

function probeServer() {
  try {
    const out = execFileSync('curl', ['-s', '-m', '2', `${API_BASE}/api/v1/meta/health`], {
      encoding: 'utf8',
      stdio: ['ignore', 'pipe', 'ignore'],
      windowsHide: true,
    });
    if (!out.trim()) return null;
    const j = JSON.parse(out);
    const rel = j?.data?.db_path;
    if (!rel) return null;
    const abs = path.isAbsolute(rel) ? rel : path.resolve(ROOT, 'backend', rel);
    if (fs.existsSync(abs)) return { file: abs, source: `后端服务 ${API_BASE} 正在使用`, rows: j.data.total_rows };
    return null;
  } catch {
    return null;
  }
}

function openDb(file, { readOnly = false } = {}) {
  const db = new DatabaseSync(file, { readOnly });
  db.exec('PRAGMA busy_timeout = 8000');
  try {
    db.exec('PRAGMA foreign_keys = ON');
  } catch { /* readOnly 下忽略 */ }
  return db;
}

function esc(v) {
  if (v instanceof Uint8Array) return `<blob:${v.length}B>`;
  return String(v);
}
function renderRows(rows) {
  if (!rows.length) return '（无记录）';
  const cols = Object.keys(rows[0]);
  const widths = cols.map((c) => Math.max(strw(c), ...rows.map((r) => strw(esc(r[c] ?? '')))));
  const line = (l, m, r) => l + widths.map((w) => '─'.repeat(w + 2)).join(m) + r;
  const row = (vals) => '│' + vals.map((v, i) => ' ' + pad(esc(v ?? ''), widths[i]) + ' ').join('│') + '│';
  const out = [line('┌', '┬', '┐'), row(cols), line('├', '┼', '┤')];
  for (const r of rows) out.push(row(cols.map((c) => r[c])));
  out.push(line('└', '┴', '┘'));
  return out.join('\n');
}
/** 中文按 2 个宽度算，保证表格对齐 */
function strw(s) {
  let w = 0;
  for (const ch of String(s)) w += /[\u1100-\u115F\u2E80-\uA4CF\uAC00-\uD7A3\uF900-\uFAFF\uFE30-\uFE6F\uFF00-\uFF60\uFFE0-\uFFE6]/.test(ch) ? 2 : 1;
  return w;
}
function pad(s, w) {
  const d = w - strw(s);
  return s + ' '.repeat(Math.max(0, d));
}

/* ============================ 3. SQL 解析与静态校验 ============================ */

/** 按顶层分号切分语句，正确跳过字符串、注释、括号 */
function splitStatements(sql) {
  const out = [];
  let cur = '';
  let depth = 0;
  let q = null;
  for (let i = 0; i < sql.length; i += 1) {
    const c = sql[i];
    const n = sql[i + 1];
    if (q) {
      cur += c;
      if (c === q) {
        if (n === q) { cur += n; i += 1; } else q = null;
      }
      continue;
    }
    if (c === '-' && n === '-') { while (i < sql.length && sql[i] !== '\n') i += 1; cur += '\n'; continue; }
    if (c === '/' && n === '*') { i += 2; while (i < sql.length && !(sql[i] === '*' && sql[i + 1] === '/')) i += 1; i += 1; continue; }
    if (c === "'" || c === '"') { q = c; cur += c; continue; }
    if (c === '(') { depth += 1; cur += c; continue; }
    if (c === ')') { depth -= 1; cur += c; continue; }
    if (c === ';' && depth === 0) { if (cur.trim()) out.push(cur.trim()); cur = ''; continue; }
    cur += c;
  }
  if (cur.trim()) out.push(cur.trim());
  return out;
}

/** 按顶层分隔符切分（用于列清单、VALUES 元组、SET 赋值） */
function splitTop(s, sep = ',') {
  const out = [];
  let cur = '';
  let depth = 0;
  let q = null;
  for (let i = 0; i < s.length; i += 1) {
    const c = s[i];
    const n = s[i + 1];
    if (q) {
      cur += c;
      if (c === q) { if (n === q) { cur += n; i += 1; } else q = null; }
      continue;
    }
    if (c === "'" || c === '"') { q = c; cur += c; continue; }
    if (c === '(' || c === '[') { depth += 1; cur += c; continue; }
    if (c === ')' || c === ']') { depth -= 1; cur += c; continue; }
    if (c === sep && depth === 0) { out.push(cur.trim()); cur = ''; continue; }
    cur += c;
  }
  if (cur.trim() !== '') out.push(cur.trim());
  return out;
}

/** 在顶层查找关键字（如 SET 之后的 WHERE），返回其起始下标 */
function findTopKeyword(s, kw) {
  let depth = 0;
  let q = null;
  const upper = s.toUpperCase();
  for (let i = 0; i < s.length; i += 1) {
    const c = s[i];
    const n = s[i + 1];
    if (q) { if (c === q) { if (n === q) i += 1; else q = null; } continue; }
    if (c === "'" || c === '"') { q = c; continue; }
    if (c === '(') { depth += 1; continue; }
    if (c === ')') { depth -= 1; continue; }
    if (depth === 0 && upper.startsWith(kw, i)) {
      const before = i === 0 ? ' ' : s[i - 1];
      const after = s[i + kw.length] || ' ';
      if (!/[A-Za-z0-9_]/.test(before) && !/[A-Za-z0-9_]/.test(after)) return i;
    }
  }
  return -1;
}

/** 抽出 SQL 字面量/表达式里"裸"的标量值，用于枚举比对 */
function literalValue(expr) {
  const e = String(expr).trim();
  if (/^null$/i.test(e)) return { kind: 'null' };
  if (/^'.*'$/s.test(e)) return { kind: 'text', value: e.slice(1, -1).replace(/''/g, "'") };
  if (/^".*"$/s.test(e)) return { kind: 'text', value: e.slice(1, -1).replace(/""/g, '"') };
  if (/^-?\d+(\.\d+)?$/.test(e)) return { kind: 'number', value: Number(e) };
  return { kind: 'expr' };
}

const KIND_RE = {
  insert: /^\s*INSERT\s+(?:OR\s+[A-Z]+\s+)?INTO\s+([^\s(]+)\s*(?:\(([^)]*)\))?\s*(?:VALUES|SELECT|DEFAULT\s+VALUES)/is,
  update: /^\s*UPDATE\s+(?:OR\s+[A-Z]+\s+)?([^\s(]+)\s+SET\s+/is,
  delete: /^\s*DELETE\s+FROM\s+([^\s(]+)/is,
  select: /^\s*(?:SELECT|WITH)\b/is,
};

function classify(stmt) {
  if (/^\s*PRAGMA|^\s*BEGIN|^\s*COMMIT|^\s*ROLLBACK|^\s*SAVEPOINT|^\s*RELEASE/i.test(stmt)) return { kind: 'noop' };
  for (const [kind, re] of Object.entries(KIND_RE)) {
    const m = stmt.match(re);
    if (m) {
      if (kind === 'select' || kind === 'delete') return { kind, table: m[1] ? String(m[1]).replace(/["'`\[\]]/g, '') : null };
      const table = String(m[1]).replace(/["'`\[\]]/g, '');
      if (kind === 'insert') {
        return { kind, table, cols: m[2] ? splitTop(m[2]).map((x) => x.replace(/["'`\[\]]/g, '').trim()) : null, rest: stmt.slice((m.index ?? 0) + m[0].length) };
      }
      const setStart = (m.index ?? 0) + m[0].length;
      const body = stmt.slice(setStart);
      const wi = findTopKeyword(body, 'WHERE');
      const setPart = wi >= 0 ? body.slice(0, wi) : body;
      return { kind, table, setPart };
    }
  }
  return { kind: 'unknown', raw: stmt };
}

/** 静态校验：表名 / 列名 / 枚举 / 必填；返回 {errors, warnings, ops} */
function validateStatement(stmt, idx) {
  const errors = [];
  const warnings = [];
  const info = classify(stmt);
  if (info.kind === 'noop' || info.kind === 'unknown') {
    if (info.kind === 'unknown') warnings.push({ code: 'UNPARSED', msg: '无法识别的语句类型，执行前请人工确认' });
    return { info, errors, warnings };
  }
  if (info.kind === 'select' || info.kind === 'delete') return { info, errors, warnings };

  const def = TABLES.get(info.table);
  if (!def) {
    errors.push({ code: 'UNKNOWN_TABLE', msg: `表 "${info.table}" 不在白名单内` });
    return { info, errors, warnings };
  }
  const cols = colMap(def);
  const check = (name, expr) => {
    const cd = cols.get(name);
    if (!cd) { errors.push({ code: 'UNKNOWN_COLUMN', table: info.table, column: name, msg: `表 ${info.table} 没有列 "${name}"` }); return; }
    const lit = literalValue(expr);
    if (lit.kind === 'null') {
      if (cd.notNull && !cd.default) warnings.push({ code: 'NULL_NOTNULL', table: info.table, column: name, msg: `${name} 是 NOT NULL，写入 NULL 会失败` });
      return;
    }
    if (lit.kind !== 'text' && lit.kind !== 'number') return;
    const en = enumOf(info.table, name, cd);
    if (en) {
      const ok = en.some((v) => String(v) === String(lit.value));
      if (!ok) errors.push({ code: 'BAD_ENUM', table: info.table, column: name, value: lit.value, expected: en, msg: `${name} = ${JSON.stringify(lit.value)} 不在枚举内，合法值：${en.map((v) => JSON.stringify(v)).join(' / ')}` });
    } else if (cd.type === 'INTEGER' && lit.kind === 'text' && !/^-?\d+$/.test(lit.value)) {
      warnings.push({ code: 'TYPE_MISMATCH', table: info.table, column: name, msg: `${name} 是 INTEGER，写的是文本 ${JSON.stringify(lit.value)}` });
    } else if (cd.boolean && lit.kind === 'number' && ![0, 1].includes(lit.value)) {
      errors.push({ code: 'BAD_BOOL', table: info.table, column: name, value: lit.value, msg: `${name} 是 0/1 布尔列，取了 ${lit.value}` });
    }
  };

  if (info.kind === 'insert') {
    const rest = info.rest || '';
    const tupleM = rest.match(/^\s*\(([\s\S]*)\)\s*$/);
    let values = null;
    if (tupleM) values = splitTop(tupleM[1]);
    else if (/^\s*SELECT/i.test(rest)) warnings.push({ code: 'INSERT_SELECT', msg: 'INSERT ... SELECT 不逐列校验，请人工确认' });

    if (!info.cols && values) errors.push({ code: 'NO_COLUMN_LIST', table: info.table, msg: 'INSERT 缺少列清单，无法校验（请写成 INSERT INTO t (a,b) VALUES (...)' });
    if (info.cols && values && info.cols.length !== values.length) {
      errors.push({ code: 'COUNT_MISMATCH', table: info.table, msg: `列数 ${info.cols.length} 与值个数 ${values.length} 不一致` });
    }
    if (info.cols) info.cols.forEach((c, i) => check(c, values ? values[i] ?? 'NULL' : 'NULL'));
    // 必填列检查
    if (info.cols) {
      for (const c of def.columns) {
        if (c.notNull && !c.default && !c.autoIncrement && c.name !== 'id' && !info.cols.includes(c.name)) {
          warnings.push({ code: 'MISSING_REQUIRED', table: info.table, column: c.name, msg: `NOT NULL 列 ${c.name} 未赋值，插入会失败，请补上或给默认值` });
        }
      }
    }
  }

  if (info.kind === 'update') {
    const assigns = splitTop(info.setPart || '');
    for (const a of assigns) {
      const m = a.match(/^\s*([A-Za-z_][A-Za-z0-9_]*)\s*=\s*([\s\S]+)$/);
      if (!m) { warnings.push({ code: 'UNPARSED_ASSIGN', msg: `无法解析赋值：${a}` }); continue; }
      if (m[1] === 'id') warnings.push({ code: 'PK_UPDATE', table: info.table, msg: '正在修改主键 id，请确认这是有意的' });
      check(m[1], m[2]);
    }
  }

  return { info, errors, warnings };
}

function statementKindLabel(k) {
  return { insert: '新增', update: '修改', delete: '删除', select: '查询', noop: '忽略', unknown: '未知' }[k] || k;
}

/* ============================ 4. 子命令 ============================ */

const argv = process.argv.slice(2);
const cmd = argv[0];
const flags = {};
const positional = [];
for (let i = 1; i < argv.length; i += 1) {
  const a = argv[i];
  if (a.startsWith('--')) {
    const k = a.slice(2);
    const v = argv[i + 1] && !argv[i + 1].startsWith('--') ? argv[++i] : true;
    flags[k] = v;
  } else positional.push(a);
}
const asJson = !!flags.json;

const COMMANDS = {
  dbinfo, tables, schema, enums, find, q, 'find-any': findAny, check, apply, help,
};

/* --- dbinfo --- */
function dbinfo() {
  const r = resolveDbPath(flags.db);
  const st = fs.statSync(r.file);
  const db = openDb(r.file, { readOnly: true });
  let count = 0;
  let pageSize = 0;
  let journal = '';
  try {
    count = db.prepare("SELECT count(*) AS n FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%'").get().n;
    pageSize = db.prepare('PRAGMA page_size').get().page_size;
    journal = db.prepare('PRAGMA journal_mode').get().journal_mode;
  } catch { /* ignore */ }
  db.close();
  const out = {
    数据库文件: r.file,
    来源: r.source,
    体积: `${(st.size / 1024).toFixed(1)} KB`,
    修改时间: st.mtime.toISOString(),
    表数量: count,
    页大小: pageSize,
    journal_mode: journal,
    项目根目录: ROOT,
    schema元数据: `${SCHEMA.meta.tableCount} 表 / ${SCHEMA.meta.columnCount} 列（生成于 ${SCHEMA.meta.generatedAt}）`,
  };
  if (asJson) return console.log(JSON.stringify(out, null, 2));
  for (const [k, v] of Object.entries(out)) console.log(`${pad(k, 14)}: ${v}`);
}

/* --- tables --- */
function tables() {
  const r = resolveDbPath(flags.db);
  const db = openDb(r.file, { readOnly: true });
  const rows = [];
  for (const t of SCHEMA.tables) {
    let n = null;
    try { n = db.prepare(`SELECT count(*) AS n FROM "${t.name}"`).get().n; } catch { /* ignore */ }
    rows.push({ 分组: t.group, 表名: t.name, 行数: n, 列数: t.columns.length, 说明: t.comment || '' });
  }
  db.close();
  if (asJson) return console.log(JSON.stringify(rows, null, 2));
  let group = '';
  for (const row of rows) {
    if (row.分组 !== group) {
      group = row.分组;
      console.log(`\n── ${group} ${'─'.repeat(Math.max(0, 60 - strw(group)))}`);
      console.log(`${pad('表名', 32)}${pad('行数', 8)}${pad('列数', 6)}说明`);
    }
    console.log(`${pad(row.表名, 32)}${pad(String(row.行数 ?? '-'), 8)}${pad(String(row.列数), 6)}${row.说明}`);
  }
}

/* --- schema <table> --- */
function schema() {
  const name = positional[0];
  if (!name) fail('用法：crm.mjs schema <table>');
  const def = tableDef(name);
  if (asJson) return console.log(JSON.stringify(def, null, 2));
  console.log(`表 ${def.name}   [${def.group}] ${def.comment || ''}`);
  console.log(`主键: ${def.primaryKey.join(', ')}` + (def.uniqueKeys?.length ? `   唯一键: ${def.uniqueKeys.map((u) => u.join('+')).join(' | ')}` : ''));
  if (def.foreignKeys?.length) {
    console.log('外键:');
    for (const fk of def.foreignKeys) console.log(`  ${fk.columns.join(',')}  ->  ${fk.refTable}(${fk.refColumns.join(',')})  ON DELETE ${fk.onDelete || '-'}`);
  }
  if (def.belongsTo?.length) console.log(`归属(belongsTo): ${def.belongsTo.join('  ')}`);
  if (def.hasMany?.length) console.log(`下属(hasMany): ${def.hasMany.join('  ')}`);
  console.log('');
  const rows = def.columns.map((c) => ({
    列名: c.name + (c.primaryKey ? ' [PK]' : ''),
    类型: c.sqlType,
    必填: c.notNull ? '是' : '',
    默认: c.default ?? '',
    枚举: (enumOf(def.name, c.name, c) || []).join(' / '),
    备注: c.comment || (c.json ? 'JSON' : '') + (c.boolean ? ' 0/1' : ''),
  }));
  console.log(renderRows(rows));
}

/* --- enums --- */
function enums() {
  const key = positional[0];
  const list = key ? { [key]: GLOBAL_ENUMS[key] } : GLOBAL_ENUMS;
  if (key && !GLOBAL_ENUMS[key]) fail(`没有名为 ${key} 的枚举。可用的有：${Object.keys(GLOBAL_ENUMS).join(', ')}`);
  if (asJson) return console.log(JSON.stringify(list, null, 2));
  for (const [k, v] of Object.entries(list)) console.log(`${pad(k, 20)}${v.map((x) => JSON.stringify(x)).join('  ')}`);
}

/* --- find <table> --- */
function find() {
  const name = positional[0];
  if (!name) fail('用法：crm.mjs find <table> [--like 关键字] [--col 列名] [--limit 20]');
  const def = tableDef(name);
  const cols = colMap(def);
  const limit = Math.min(Number(flags.limit) || 20, 200);
  const where = [];
  const params = [];
  const like = flags.like || flags.q;
  if (like) {
    const targets = flags.col
      ? [String(flags.col)]
      : def.columns.filter((c) => c.type === 'TEXT').map((c) => c.name);
    for (const c of targets) {
      if (!cols.has(c)) fail(`表 ${def.name} 没有列 ${c}`);
      where.push(`"${c}" LIKE ?`);
      params.push(`%${like}%`);
    }
  }
  const sql = `SELECT * FROM "${def.name}"${where.length ? ' WHERE ' + where.join(' OR ') : ''} LIMIT ${limit}`;
  const db = openDb(resolveDbPath(flags.db).file, { readOnly: true });
  const rows = db.prepare(sql).all(...params).map(plainify);
  db.close();
  if (asJson) return console.log(JSON.stringify({ table: def.name, count: rows.length, items: rows }, null, 2));
  console.log(`表 ${def.name}：命中 ${rows.length} 行${rows.length ? '（仅显示非空列）' : ''}\n`);
  const trimmed = rows.map((r) => Object.fromEntries(Object.entries(r).filter(([, v]) => v !== null && v !== '')));
  console.log(renderRows(trimmed.length ? trimmed : rows));
}

function plainify(row) {
  const o = {};
  for (const [k, v] of Object.entries(row)) o[k] = v instanceof Uint8Array ? `<blob:${v.length}B>` : v;
  return o;
}

/* --- q "<SELECT ...>" --- */
function q() {
  const sql = positional.join(' ');
  if (!sql) fail('用法：crm.mjs q "<SELECT ...>"');
  if (!/^\s*(SELECT|WITH|PRAGMA|EXPLAIN)\b/i.test(sql)) fail('q 只允许只读查询（SELECT / WITH / PRAGMA / EXPLAIN）');
  const db = openDb(resolveDbPath(flags.db).file, { readOnly: true });
  const rows = db.prepare(sql.replace(/;\s*$/, '')).all().map(plainify);
  db.close();
  if (asJson) return console.log(JSON.stringify(rows, null, 2));
  console.log(renderRows(rows));
}

/* --- find-any <keyword>：反查归属 --- */
const SEARCH_TARGETS = [
  { table: 'customer', cols: ['name', 'crm_code', 'tags'], label: '客户' },
  { table: 'coop_entity', cols: ['name', 'tags'], label: '合作/竞争方实体' },
  { table: 'project', cols: ['name'], label: '项目' },
  { table: 'person', cols: ['name', 'title', 'dept'], label: '客户人员' },
  { table: 'partner_person', cols: ['name', 'title'], label: '合作方人员' },
  { table: 'competitor_person', cols: ['name', 'title'], label: '竞争方人员' },
  { table: 'internal_person', cols: ['name', 'title', 'dept'], label: '我司内部人员' },
  { table: 'org', cols: ['name'], label: '我司组织' },
];

function findAny() {
  const kw = positional.join(' ');
  if (!kw) fail('用法：crm.mjs find-any <关键字>');
  const db = openDb(resolveDbPath(flags.db).file, { readOnly: true });
  const hits = [];
  for (const t of SEARCH_TARGETS) {
    const def = TABLES.get(t.table);
    if (!def) continue;
    const cols = colMap(def);
    const use = t.cols.filter((c) => cols.has(c));
    if (!use.length) continue;
    const sql = `SELECT id, ${use.map((c) => `"${c}"`).join(', ')} FROM "${t.table}" WHERE ${use.map((c) => `"${c}" LIKE ?`).join(' OR ')} LIMIT 10`;
    try {
      for (const r of db.prepare(sql).all(...use.map(() => `%${kw}%`))) {
        hits.push({ 类别: t.label, 表: t.table, id: r.id, 名称: r.name ?? r[use[1]] ?? '', 其他: use.slice(1).map((c) => (r[c] ? `${c}=${r[c]}` : '')).filter(Boolean).join(' ') });
      }
    } catch { /* 忽略单表异常 */ }
  }
  // 命中人员时顺带给出上级归属
  for (const h of hits) {
    if (h.表 === 'person') {
      const up = db.prepare('SELECT c.id, c.name FROM customer c JOIN person p ON p.customer_id=c.id WHERE p.id=?').get(h.id);
      if (up) h.归属 = `客户 ${up.name} (customer.id=${up.id})`;
    } else if (h.表 === 'partner_person' || h.表 === 'competitor_person') {
      const up = db.prepare(`SELECT e.id, e.name, e.entity_type FROM coop_entity e JOIN ${h.表} p ON p.coop_entity_id=e.id WHERE p.id=?`).get(h.id);
      if (up) h.归属 = `${up.entity_type === 'partner' ? '合作方' : up.entity_type === 'competitor' ? '竞争方' : '竞合'} ${up.name} (coop_entity.id=${up.id})`;
    } else if (h.表 === 'internal_person') {
      const up = db.prepare('SELECT o.id, o.name, o.org_type, o.level FROM org o JOIN internal_person p ON p.org_id=o.id WHERE p.id=?').get(h.id);
      if (up) h.归属 = `组织 ${up.name} (org.id=${up.id}, level=${up.level})`;
    } else if (h.表 === 'project') {
      const up = db.prepare('SELECT c.id, c.name FROM customer c JOIN project p ON p.customer_id=c.id WHERE p.id=?').get(h.id);
      if (up) h.归属 = `客户 ${up.name} (customer.id=${up.id})`;
    }
  }
  db.close();
  if (asJson) return console.log(JSON.stringify(hits, null, 2));
  if (!hits.length) { console.log(`没有找到与「${kw}」匹配的客户 / 人员 / 项目 / 实体 / 组织。`); return; }
  console.log(`与「${kw}」相关的已有记录（共 ${hits.length} 条）：\n`);
  console.log(renderRows(hits));
}

/* --- check <file.sql> --- */
function readSqlFile() {
  const f = positional[0];
  if (!f) fail('用法：crm.mjs check <file.sql>');
  const p = path.resolve(f);
  if (!fs.existsSync(p)) fail(`SQL 文件不存在：${p}`);
  return { file: p, sql: fs.readFileSync(p, 'utf8') };
}

function check() {
  const { file, sql } = readSqlFile();
  const stmts = splitStatements(sql);
  const results = stmts.map((s, i) => ({ idx: i + 1, stmt: s, ...validateStatement(s, i) }));
  const errors = results.flatMap((r) => r.errors.map((e) => ({ ...e, stmt: r.idx })));
  const warnings = results.flatMap((r) => r.warnings.map((w) => ({ ...w, stmt: r.idx })));

  if (asJson) return console.log(JSON.stringify({ file, statements: stmts.length, results: results.map(({ stmt, ...r }) => r), errors, warnings }, null, 2));

  console.log(`校验文件：${file}`);
  console.log(`共 ${stmts.length} 条语句\n`);
  for (const r of results) {
    const t = r.info.table ? ` ${r.info.table}` : '';
    console.log(`  [${r.idx}] ${statementKindLabel(r.info.kind)}${t}`);
    for (const m of new Set(r.warnings.map((w) => w.msg))) console.log(`       ⚠︎  ${m}`);
    for (const m of new Set(r.errors.map((e) => e.msg))) console.log(`       ✖  ${m}`);
  }
  console.log(`\n合计：${errors.length} 处错误，${warnings.length} 处提醒。`);
  if (errors.length) { console.log('存在错误，请修正后再执行。'); process.exit(2); }
  if (!warnings.length) console.log('静态校验通过。');
}

/* --- apply <file.sql> [--dry-run] --- */
function apply() {
  const { file, sql } = readSqlFile();
  const dryRun = !!flags['dry-run'];
  const stmts = splitStatements(sql).filter((s) => !/^\s*(BEGIN|COMMIT|ROLLBACK)\b/i.test(s));
  if (!stmts.length) fail('SQL 文件里没有可执行的语句。');

  // 先静态校验，有错不碰库
  const pre = stmts.map((s, i) => ({ idx: i + 1, ...validateStatement(s, i) }));
  const errors = pre.flatMap((r) => r.errors);
  if (errors.length) {
    console.error('静态校验未通过，已中止（未改动数据库）：');
    for (const e of errors) console.error(`  ✖ ${e.msg}`);
    process.exit(2);
  }

  const r = resolveDbPath(flags.db);
  const db = openDb(r.file);
  const applied = [];
  let txOpen = false;
  try {
    db.exec('BEGIN IMMEDIATE');
    txOpen = true;
    stmts.forEach((s, i) => {
      const info = classify(s);
      const cnt = (s.match(/\?/g) || []).length;
      if (cnt) throw new Error(`第 ${i + 1} 条语句含 ${cnt} 个占位符 ?，请写成完整字面量 SQL`);
      const st = db.prepare(s);
      const out = st.run();
      applied.push({ idx: i + 1, kind: info.kind, table: info.table || null, changes: Number(out.changes ?? 0), lastInsertRowid: out.lastInsertRowid != null ? Number(out.lastInsertRowid) : null, sql: s });
    });
    if (dryRun) db.exec('ROLLBACK');
    else db.exec('COMMIT');
    txOpen = false;
  } catch (err) {
    if (txOpen) { try { db.exec('ROLLBACK'); } catch { /* ignore */ } }
    db.close();
    console.error(`✖ 执行失败，已整体回滚，数据库未发生任何变化。\n  原因：${err.message}`);
    process.exit(3);
  }
  db.close();

  const total = applied.reduce((a, x) => a + x.changes, 0);
  if (asJson) return console.log(JSON.stringify({ mode: dryRun ? 'dry-run' : 'apply', db: r.file, totalChanges: total, applied }, null, 2));

  console.log(`${dryRun ? '【试运行 dry-run】已执行并回滚，数据库未改变。' : '【已提交】数据库已写入。'}`);
  console.log(`目标库：${r.file}（${r.source}）\n`);
  const rows = applied.map((a) => ({
    序号: a.idx,
    操作: statementKindLabel(a.kind),
    表: a.table ?? '',
    影响行数: a.changes,
    新记录ID: a.lastInsertRowid ?? '',
  }));
  console.log(renderRows(rows));
  console.log(`\n合计影响 ${total} 行${dryRun ? '（试运行，未落库）' : ''}。`);
}

/* --- help --- */
function help() {
  console.log(`crm.mjs —— 客户管理系统归档工具

  dbinfo                              数据库位置、体积、来源
  tables                              61 张表清单 + 行数
  schema <table>                      某表的列 / 类型 / 枚举 / 外键 / 必填
  enums [列名]                         枚举字典
  find <table> [--like 关键字] [--col 列名] [--limit 20]
                                      按关键字查某张表（默认扫全部文本列）
  q "<SELECT ...>"                     只读查询，直接返回 JSON/表格
  find-any <关键字>                    全库反查：这个客户/人/项目/实体/组织是谁
  check <file.sql>                     静态校验（表名/列名/枚举/必填），不改库
  apply <file.sql> [--dry-run]         事务执行；--dry-run 执行后回滚

  通用参数：--json 输出机器可读 JSON     --db <path> 指定数据库文件
`);
}

/* ============================ 入口 ============================ */
(async () => {
  if (!cmd || cmd === 'help' || flags.help) return help();
  const fn = COMMANDS[cmd];
  if (!fn) fail(`未知子命令 "${cmd}"。用 crm.mjs help 查看用法。`);
  fn();
})();
