---
name: bcrm-frontend-api
description: 把 BCRM 前端接到 Rust axum 后端（127.0.0.1:8787）时的完整规程：查表结构陷阱、写字段适配器、配 CORS、用真实浏览器验证跨源。当需要让前端读真实库、新增表映射、排查「后端说成功前端没数据」、或调整数据源双通道时使用。
agent_created: true
---

# BCRM 前后端联调规程

## 何时用

- 前端要读真实库（而不是 mock），或新增一张表的展示
- 出现「后端日志正常但前端拿不到数据」→ 九成是 CORS
- 需要核对某表能不能写（枚举 / JSON 列 / 必填）

## 环境事实

| 项 | 值 |
| --- | --- |
| 后端 | `backend/target/debug/bcrm-backend.exe`，API 前缀 `/api/v1` |
| 启动 | `--port 8787 --db ./data/smoke.db`（cwd 为 `backend/`） |
| 编译 | `~/.cargo/bin/cargo.exe build`（**先停掉运行中的实例**，否则 `LNK1104` 链不上） |
| 前端 | `style-lab/`，构建 `node style-lab/_build.mjs`（单文件 `node style-lab/_single.mjs`） |
| 预览 | `node node_modules/vite/bin/vite.js preview --host 127.0.0.1 --port 4173 --strictPort`（是 `--strictPort`，没有 `--strictHost`） |
| 规模 | **62 表 / 848 列 / 32 索引**；改 DDL 后必须重跑 `tools/build_api_docs.py` 并同步 `backend/resources/schema.json` |

## 铁律一：不要凭印象写列名

**必须**先用元数据接口核对，不要猜。两个来源：

```bash
# 列 + 枚举 + JSON 标记 + 必填 + 外键
curl "http://127.0.0.1:8787/api/v1/meta/tables/<表名>"
```

或用 `node:sqlite` 直接读库文件（**必须 Node 24**，22 会报 ExperimentalWarning）：

```js
const db = new DatabaseSync('<库路径>', { readOnly: true })
db.prepare('PRAGMA table_info("customer")').all()      // 列
db.prepare('PRAGMA foreign_key_list("person")').all()  // 外键
```

### 已踩过的坑（实测纠正）

| 表.列 | 真实情况 | 错误直觉 |
| --- | --- | --- |
| `partner_person.coop_entity_id` | 关联列叫这个 | ✗ 以为叫 `entity_id` |
| `competitor_person.coop_entity_id` | 同上 | ✗ 同上 |
| `attitude`（多表） | 枚举 `["X","-","=","+","⭐"]` 五级 | ✗ 以为 1/0/-1 |
| `internal_person.decision_role` | 枚举 `["拍板","协调","支撑","执行"]` | ✗ 当成 ADUR 的 A/D/U/R |
| `partner_person.decision_power` | 枚举 `["拍板","影响","执行"]` | ✗ 以为 高/中/低 |
| `project.info_type` | 枚举 `["线索","商机","项目"]`，**阶段取它最准** | ✗ 去读 `time_phase`（自由文本） |
| `project.tender_mode` | 枚举含「**邀请招标**」 | ✗ 写成「邀标」直接 400 |
| `coop_entity.company_type` | 枚举 `["代理商","集成商","原厂","渠道","厂商","其他"]` | ✗ 写成「系统集成商」 |
| `project_member.adur_role` | **自由文本**，无枚举 | ✓ 可用 A/D/U/R |

### JSON 列（传对象或数组，不能传裸字符串，否则 400「JSON 列内容非法」）

`customer.key_scenes` · `project_member.p3p4_flags` ·
`coop_entity.product_matrix` / `market_share` / `fab_talk`

## 铁律二：查询串必须展开成 `filter[列名]=值`

**这是本项目最难查的一个 bug，务必先看这条。**

`new URLSearchParams({ filter: { a: 1 } })` 会把对象 `String()` 成 `filter=[object Object]`，
后端返回 **400**；而上层的 `safe()` 又会静默兜成空数组，于是表现为
**界面渲染完好、所有列表数据全空、控制台一片安静**。

```js
// ✗ 错：filter=[object+Object] → 400
new URLSearchParams({ filter: { category: '主客户' } })

// ✓ 对：filter[category]=主客户
function qs(params) {
  const sp = new URLSearchParams()
  const add = (k, v) => {
    if (v === undefined || v === null || v === '') return
    if (Array.isArray(v)) return v.forEach((x) => add(k, x))
    sp.append(k, String(v))
  }
  const isObj = (v) => v !== null && typeof v === 'object' && !Array.isArray(v)
  for (const [k, v] of Object.entries(params || {})) {
    if (v === undefined || v === null || v === '') continue
    if (k === 'filter' && isObj(v)) {                 // filter: {a:1,b:2} → filter[a]=1&filter[b]=2
      for (const [col, val] of Object.entries(v)) add(`filter[${col}]`, val); continue
    }
    if ((k === 'or' || k === 'and') && Array.isArray(v)) {  // or: [{a:1},{b:2}] → or[0][a]=1&or[1][b]=2
      v.forEach((g, i) => { if (isObj(g)) for (const [col, val] of Object.entries(g)) add(`${k}[${i}][${col}]`, val) })
      continue
    }
    add(k, v)
  }
  const s = sp.toString()
  return s ? `?${s}` : ''
}
```

操作符写在键名里：`filter: { 'created_at__gte': '2026-01-01' }`、`{ 'item__like': '%foo%' }`；
`order_by` 支持 `col:desc` 与 `-col`，**最多 5 列**。

### 翻页：列表接口一律自动补齐

`page_size` 上限 **200**，`person` / `internal_person` 真实数据会超一页。
只取第一页会**安静地少数据**（第二难查的 bug）。`fetchAll(table, params, { maxPages = 25 })` 负责翻完。

### 表行数：一次请求拿全，不要逐表 count

`GET /api/v1/meta/health` 的 `data.tables[]` 里每张表都带 `rows`：

```js
const h = await api.health()
for (const t of h?.tables ?? []) out[t.table] = Number(t.rows) || 0   // 62 张表只要 1 个请求
```

条件查询用 `countTable(table, { refresh })`（进程内缓存），别每张表发一次 `count`。

## 铁律三：CORS 是必需组件，不是开发期临时措施

Tauri 里前端跑在 `tauri://localhost`、API 在 `http://127.0.0.1:<端口>`，**依然是跨源**。

后端 `routes.rs` 的 `cors_layer()` 已实现白名单放行（`Cargo.toml` 需 `tower-http = { features = ["cors"] }`，体积仅 +99KB / +1.3%）：

```rust
CorsLayer::new()
    .allow_origin(AllowOrigin::predicate(|origin, _req| {
        let o = origin.to_str().unwrap_or("");
        o == "null"                              // file:// 打开的单文件版
            || o.starts_with("http://127.0.0.1:") // Vite dev / preview
            || o.starts_with("http://localhost:")
            || o == "tauri://localhost"           // Tauri 2 WebView
            || o == "http://tauri.localhost"
    }))
    .allow_methods(Any).allow_headers(Any)
    .max_age(Duration::from_secs(3600))
```

**判定方法**：`OPTIONS` 预检若返回 **405**、响应无 `access-control-*` 头 → CORS 没生效。

### `file://` 有个反直觉的地方

在 `file://` 下 `location.origin` 打印出来是 **`"file://"`**，但浏览器实际发出去的
请求头是 **`Origin: null`** —— **白名单匹配的是后者**。所以：

- 白名单里必须有 `o == "null"` 这一条，双击打开的单文件版才能连上后端
- 排查时**不要**拿 `location.origin` 的值去和 `AllowOrigin` 的判断条件比对，会得出错误结论
- 验证方式就一条：在 `file://` 页面里真的 `fetch` 一次，看是否 200

实测（`tools/_verify_single_file.mjs`）：`protocol:"file:"`、`inlineStyle:1`、
`externalScripts:0`、跨源 `fetch` → `{ok:true,status:200,code:0,tableCount:62}`、指示灯 `dot--online`。

## 铁律四：用真实浏览器验证，不要用 Node fetch

`Node` 的 `fetch` **不做 CORS 检查**，用它测跨源会得到假阳性。必须走 CDP：

```bash
node tools/_edge.mjs 9333            # 启动 headless Edge（须前台 hold，勿 detach）
CDP_PORT=9333 node tools/browser.mjs tools/_verify_*.mjs
```

脚本里直接调：

```js
const cors = await page.evalJs(`
  try { const r = await fetch('http://127.0.0.1:8787/api/v1/meta/health');
        return { ok: r.ok, status: r.status }; }
  catch (e) { return { ok: false, error: String(e) }; }
`)
```

### 两个会让验证结果失真的 CDP 陷阱（都踩过）

**① 历史日志重放。** CDP `Log.enable` 会把**上一次页面加载**的日志补发给你，于是
早已修好的 400 会在每轮验证里反复出现，看起来像 bug 一直没修。
对策有两条，`tools/browser.mjs` 已经内置第二条：

```js
// 手工兜底：验证前清一次
await page.goto('about:blank', { wait: 300 })
page.errors.length = 0

// 更稳：main() 在 page.init() 后记一个基线，只报告本轮新增的错误
await page.wait(700)
const mark = page.errors.length
```

**② 缓存用了旧 bundle。** 重新构建后 `goto` 同一个 URL，浏览器会继续用缓存的旧 JS，
于是你验证的是**上一个版本**——所有修复看起来"没生效"。
`tools/browser.mjs` 的 `init()` 里已加：

```js
await send('Network.enable')
await send('Network.setCacheDisabled', { cacheDisabled: true })
```

**每次验证前先确认日志里打印的 bundle 文件名和你刚构建出来的一致**，不一致就是缓存问题。

### 可直接复用的验证脚本

| 脚本 | 覆盖内容 |
| --- | --- |
| `tools/_verify_app.mjs` | 外壳 / 导航 62 表 / 工作台 11 卡 / 待办写入回环 / 网络图客户级+项目级 / CRUD 列与编辑弹窗 / 风格下拉 / 明暗 / 侧栏收起，共 15 项 |
| `tools/_verify_dispatch.mjs` | 造真实 `visit_record → visit_our_staff → internal_person` 链路后核对界面，**验完自清理** |
| `tools/_verify_jump.mjs` | 「空态 → 新建表单」与「节点详情 → 跳转编辑」 |
| `tools/_shots.mjs` | 多风格截图 + 对比度计算 + 414px 响应式 + `file://` 单文件自检 |
| `tools/_shot_project.mjs` | 项目级一暗一亮实拍 + 「收起/展开视图侧栏」的浮窗规则回归 |

**多风格截图前先 `localStorage.clear()` 再重载** —— 风格是持久化的，否则"第一张图是什么色调"不可控。

### 断言要写"这一轮该是什么"，不要只 log

本项目最有价值的一条断言就是这个模式：

```js
projPanelOpen: !!document.querySelector('.panel'),
sideOpen: !document.querySelector('.side').classList.contains('side--mini'),
panelOverlapCanvas: (() => {           // 浮窗是否压住画布
  const p = document.querySelector('.panel');
  const c = document.querySelector('.graph-canvas');
  if (!p || !c) return false;
  const a = p.getBoundingClientRect(), b = c.getBoundingClientRect();
  return !(a.right < b.left || a.left > b.right || a.bottom < b.top || a.top > b.bottom);
})(),
```

只 `log` 出来的数字没人会回头看第二遍；把"侧栏展开时不该弹浮窗"写成布尔，
回归时一眼就能看出是否退化。

## 前端数据层结构

```
src/api/client.js              fetch 封装，统一解析 {code,message,data}；ApiError 带 kind(offline/timeout/http/api)
src/api/adapters.js            后端行 → 前端模型；命名差异与外键在这层消化
src/composables/useDataSource.js   mock/实时 双通道，失败自动回落
```

**组件层不得直接调 API**。数据统一由 `App.vue` 通过 `:dataset` 注入 `DemoPage`，
`DemoPage` 内部 `const D = computed(() => props.dataset ?? MOCK_DATASET)`。
两条通道产出**完全相同形状**，组件无需关心来源。

新增字段映射时只改 `adapters.js`，不要动组件。

### 映射示例

```
project.sec_budget   → secBudget
project.win_score    → winRate
project.competition  → competition   （值本身就一致，无需转换）
project.customer_id  → customer 名   （需先建 id→name Map）
project.info_type    → stage         （线索/商机/项目）
```

## 演示数据

`tools/_seed_demo.mjs` 灌入 26 条有代表性的数据（客户/项目/人员树/ADUR/合作竞争方/org/我方团队/C74111）：

```bash
node tools/_seed_demo.mjs            # 灌入（记录 id 到 .workbuddy/seed-manifest.json）
node tools/_seed_demo.mjs --clean    # 按 manifest 倒序删除
```

## 排查顺序

1. 后端活着吗 → `GET /api/v1/meta/health`
2. **请求 URL 对吗** → 看 Network 里 `filter[...]` 有没有变成 `filter=[object Object]`（铁律二）
   → 是的话直接 400，且前端会因为 `safe()` 兜底而**毫无报错**，只是数据全空
3. CORS 通吗 → `OPTIONS` 是否 200 + 有 ACAO 头；浏览器内 fetch 是否成功
4. 有数据吗 → banner 上的各表行数（`customer 3 · project 0` 这种）；库空 ≠ 接口坏
5. 字段对吗 → 对照上面的陷阱表，尤其枚举与 JSON 列
6. 前端报错 → 清空 `page.errors` 后重新加载，只信本次加载的错误
7. **bundle 名对吗** → 日志打印的 js 文件名必须和你刚构建出来的那个一致（铁律四）

## 改 DDL 时容易漏的地方

新增一张表要**四处同步**，少一处就会在某条路径上翻车：

1. `客户管理系统SQLite建库语句.md` —— DDL 单一事实来源
2. `backend/resources/schema.sql` —— 编译期内嵌的副本（**漏了这处，新建库就没这张表**）
3. 重跑 `tools/build_api_docs.py` → 刷新 `backend/resources/schema.json` + `客户管理系统表结构元数据.json`
4. 重编译后端并**先停掉运行中的实例**，否则 `LNK1104`

加 `CHECK (...)` 前先想一下**列名会不会撞上别的表**。`tools/build_api_docs.py` 里
`collect_enums()` 是按**列名**归并的，而且用 `setdefault` —— **先遇到的那张表赢**：

```python
def collect_enums(tables):
    bag = {}
    for t in tables:
        for c in t["columns"]:
            if c["enum"]:
                bag.setdefault(c["name"], sorted(set(c["enum"])))   # ← 同名只留第一个
```

实测这个合并是**有损的**（`enums` 共 44 个键）：

| 列名 | 实际出现在 | 全局 `enums` 里留下了什么 |
| --- | --- | --- |
| `info_type` | `customer_opportunity` / `project` | `["商机","线索"]` —— **`project` 的「项目」被吃掉了** |
| `category` | `customer` / `news_item` | `["主客户","关联客户"]` —— `news_item` 的四个取值全丢 |
| `entity_type` | 15 张表 | 只剩 `["both","competitor","partner"]` |

**目前不影响功能**：表单选项读的是 `/meta/tables/{表名}` 的**按列** `enum`（权威、完整），
`/meta/enums` 只出现在文档附录里。**但不要去用 `/meta/enums` 渲染下拉框**，会漏选项。

加 CHECK 时的实际建议：取值独特的列，**起个独有的列名**（例：番茄钟用 `outcome` 而不是 `status`），
这样既不会和别的表的同名列抢 `enums` 键，也不会让别的表的枚举误校验本表。
