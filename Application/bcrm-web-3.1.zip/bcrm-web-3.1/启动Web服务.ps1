﻿<#
    BCRM 客户管理系统 · Web 版一键启动（后端 HTTP API + 浏览器前端）

    这个脚本做四件事，全部从源码开始：
      1. 把 Rust 后端编译出来（cargo build --release，增量很快）
      2. 先做一次数据库自检，确认库文件可读可写、并打印它的落点
      3. 起后端（如果 8787 被占，自动往后找空闲端口）
      4. 前端 npm install（缺依赖时才装）→ npm run dev / build+preview，
         最后用默认浏览器打开

    为什么要「反代」而不是让前端直连后端端口：
      浏览器里前端在 5273、后端在 8787，属于跨源。走 vite 的 /api 反代后
      变成同源请求，后端换端口也不用重新构建前端产物。

    用法（双击「启动Web服务.bat」等价于无参数运行）：

      .\启动Web服务.ps1                    开发模式：后端 + 前端热更新（默认）
      .\启动Web服务.ps1 -Mode release      交付模式：后端 + 前端构建产物静态服务
      .\启动Web服务.ps1 -Service backend   只起后端 API
      .\启动Web服务.ps1 -Service frontend  只起前端（后端已在别处运行）
      .\启动Web服务.ps1 -Stop              停止本项目占用的端口上的服务
      .\启动Web服务.ps1 -Port 9000         换后端端口
      .\启动Web服务.ps1 -Reinstall         强制重装前端依赖（npm ci）

    安全提示：后端只监听 127.0.0.1，且当前 API 没有任何鉴权 ——
    这套脚本默认**不对外网/局域网暴露**，请不要改成绑定 0.0.0.0。
#>
#Requires -Version 5.1
[CmdletBinding()]
param(
    # dev   = 后端 + vite dev server（改前端代码即时生效，适合开发/联调）
    # release = 后端 + vite 构建产物 + preview 静态服务（更接近交付形态）
    [ValidateSet('dev', 'release')][string]$Mode = 'dev',

    # 起哪一半
    [ValidateSet('all', 'backend', 'frontend')][string]$Service = 'all',

    # 后端监听端口（被占会自动往后顺延）
    [int]$Port = 8787,

    # 前端页面端口
    [int]$WebPort = 5273,

    # 数据库文件。留空 = 用后端内置的自动定位（exe 同级 → %LOCALAPPDATA%\Bcrm → 当前目录）
    [string]$DbPath = '',

    # npm 镜像，例如 https://registry.npmmirror.com（默认用 npm 自己的配置）
    [string]$Registry = '',

    # 强制重装前端依赖（走 npm ci，需要 package-lock.json）
    [switch]$Reinstall,

    # 跳过编译/构建，直接用已有产物
    [switch]$NoBuild,

    # 不自动打开浏览器
    [switch]$NoOpen,

    # 停止服务（按端口找监听进程，核对是本项目的进程后才结束）
    [switch]$Stop
)

$ErrorActionPreference = 'Stop'

# ---------------------------------------------------------------------------
# 路径
# ---------------------------------------------------------------------------

$Root = $PSScriptRoot
if (-not $Root) { $Root = Split-Path -Parent $MyInvocation.MyCommand.Definition }

$BackendDir  = Join-Path $Root 'backend'
$FrontendDir = Join-Path $Root 'frontend'
$Manifest    = Join-Path $BackendDir 'Cargo.toml'
$BackendExe  = Join-Path $BackendDir 'target\release\bcrm-backend.exe'

# ---------------------------------------------------------------------------
# 输出小工具
# ---------------------------------------------------------------------------

function Say  { param($m, $c = 'Gray')      Write-Host $m -ForegroundColor $c }
function Head { param($m)
    Write-Host ''
    Write-Host ('=' * 66) -ForegroundColor DarkCyan
    Write-Host ("  {0}" -f $m) -ForegroundColor Cyan
    Write-Host ('=' * 66) -ForegroundColor DarkCyan
}
function Step { param([int]$n, [int]$t, $m)
    Write-Host ''
    Write-Host ("[{0}/{1}] {2}" -f $n, $t, $m) -ForegroundColor Yellow
}
function Ok   { param($m) Write-Host ("      [OK] {0}" -f $m) -ForegroundColor Green }
function Warn { param($m) Write-Host ("      [!]  {0}" -f $m) -ForegroundColor Yellow }
function Info { param($m) Write-Host ("           {0}" -f $m) -ForegroundColor DarkGray }
function Die  {
    param($m)
    Write-Host ''
    Write-Host ("  失败：{0}" -f $m) -ForegroundColor Red
    Write-Host ''
    exit 1
}

# ---------------------------------------------------------------------------
# 端口工具
# ---------------------------------------------------------------------------

# 端口是否空闲：真的去 bind 一下，比查 netstat 可靠（也不要求管理员）
function Test-PortFree {
    param([int]$P)
    $l = $null
    try {
        $l = New-Object System.Net.Sockets.TcpListener([System.Net.IPAddress]::Loopback, $P)
        $l.Start()
        $l.Stop()
        return $true
    } catch {
        if ($l) { try { $l.Stop() } catch { } }
        return $false
    }
}

# 从 Start 往后找第一个空闲端口；找不到返回 0
function Find-FreePort {
    param([int]$Start, [int]$MaxTry = 20)
    for ($p = $Start; $p -lt ($Start + $MaxTry); $p++) {
        if (Test-PortFree $p) { return $p }
    }
    return 0
}

# 谁在监听这个端口（取不到就返回 0）
function Get-PortOwnerPid {
    param([int]$P)
    try {
        $c = Get-NetTCPConnection -LocalPort $P -State Listen -ErrorAction SilentlyContinue
        if ($c) { return [int]($c | Select-Object -First 1).OwningProcess }
    } catch { }
    return 0
}

function Get-ProcInfo {
    param([int]$Pid2)
    if ($Pid2 -le 0) { return $null }
    try { return Get-Process -Id $Pid2 -ErrorAction Stop } catch { return $null }
}

# TCP 探活（不走系统代理，避免公司代理把本机请求也拦掉）
function Test-Tcp {
    param([int]$P, [int]$TimeoutMs = 900)
    $c = $null
    try {
        $c = New-Object System.Net.Sockets.TcpClient
        $iar = $c.BeginConnect('127.0.0.1', $P, $null, $null)
        if ($iar.AsyncWaitHandle.WaitOne($TimeoutMs, $false) -and $c.Connected) { return $true }
        return $false
    } catch {
        return $false
    } finally {
        if ($c) { try { $c.Close() } catch { } }
    }
}

# 直连取 JSON（不走代理）
function Invoke-Json {
    param([string]$Url)
    try {
        $wc = New-Object System.Net.WebClient
        $wc.Proxy = New-Object System.Net.WebProxy
        $wc.Headers.Add('Accept', 'application/json')
        return ($wc.DownloadString($Url) | ConvertFrom-Json)
    } catch {
        return $null
    }
}

# 等端口就绪
function Wait-Port {
    param([int]$P, [int]$TimeoutSec = 90)
    $deadline = (Get-Date).AddSeconds($TimeoutSec)
    Write-Host '      等待服务就绪 ' -NoNewline -ForegroundColor DarkGray
    while ((Get-Date) -lt $deadline) {
        if (Test-Tcp $P) { Write-Host ' 就绪' -ForegroundColor Green; return $true }
        Write-Host '.' -NoNewline -ForegroundColor DarkGray
        Start-Sleep -Milliseconds 700
    }
    Write-Host ' 超时' -ForegroundColor Red
    return $false
}

# ---------------------------------------------------------------------------
# 工具链解析（不写死安装路径，尊重用户的 PATH）
# ---------------------------------------------------------------------------

function Resolve-Exe {
    param([string]$Name, [string[]]$Fallbacks = @())
    $g = Get-Command $Name -ErrorAction SilentlyContinue
    if ($g) { return @($g)[0].Source }
    foreach ($f in $Fallbacks) {
        if ($f -and (Test-Path -LiteralPath $f)) { return $f }
    }
    return ''
}

$PF   = $env:ProgramFiles
$PF86 = ${env:ProgramFiles(x86)}
$NodeExe = Resolve-Exe 'node' @(
    (Join-Path $PF 'nodejs\node.exe'),
    (Join-Path $PF86 'nodejs\node.exe')
)
$NpmCmd = Resolve-Exe 'npm.cmd' @(
    (Join-Path $PF 'nodejs\npm.cmd'),
    (Join-Path $PF86 'nodejs\npm.cmd')
)
$CargoExe = Resolve-Exe 'cargo' @( (Join-Path $env:USERPROFILE '.cargo\bin\cargo.exe') )

# ---------------------------------------------------------------------------
# npm 调用（切到前端目录执行）
# ---------------------------------------------------------------------------

function Invoke-Npm {
    param([string[]]$NpmArgs)
    $prev = (Get-Location).Path
    try {
        Set-Location -LiteralPath $FrontendDir
        & $NpmCmd @NpmArgs
        return $LASTEXITCODE
    } finally {
        Set-Location -LiteralPath $prev
    }
}

# ---------------------------------------------------------------------------
# -Stop：停止本项目的服务
# ---------------------------------------------------------------------------

function Stop-Services {
    Head '停止 BCRM Web 服务'
    $targets = @()
    if ($Service -ne 'frontend') { $targets += [pscustomobject]@{ Name = '后端 API'; Port = $Port } }
    if ($Service -ne 'backend')  { $targets += [pscustomobject]@{ Name = '前端页面'; Port = $WebPort } }

    foreach ($t in $targets) {
        $ownerPid = Get-PortOwnerPid $t.Port
        if ($ownerPid -le 0) {
            Info ("端口 {0}（{1}）没有监听进程，已停或未启动" -f $t.Port, $t.Name)
            continue
        }
        $p = Get-ProcInfo $ownerPid
        if (-not $p) {
            Warn ("端口 {0} 被 PID {1} 占用，但取不到进程信息，跳过" -f $t.Port, $ownerPid)
            continue
        }
        $path = ''
        try { $path = $p.Path } catch { }

        # 只结束「确实是本项目」的进程：后端 exe 名固定；
        # 前端是 node.exe 且工作目录在本仓库下（取不到路径时保守起见不动手）。
        $isOurs = $false
        if ($p.ProcessName -ieq 'bcrm-backend') { $isOurs = $true }
        elseif ($p.ProcessName -ieq 'node' -and $path -and $path.StartsWith($Root, [StringComparison]::OrdinalIgnoreCase)) { $isOurs = $true }

        if (-not $isOurs) {
            Warn ("端口 {0} 被 {1}（PID {2}）占用 —— 看起来不是本项目，未结束它" -f $t.Port, $p.ProcessName, $ownerPid)
            if ($path) { Info ("路径：{0}" -f $path) }
            continue
        }

        try {
            Stop-Process -Id $ownerPid -Force -ErrorAction Stop
            Ok ("已停止 {0}：{1}（PID {2}）" -f $t.Name, $p.ProcessName, $ownerPid)
        } catch {
            Warn ("停止 PID {0} 失败：{1}" -f $ownerPid, $_.Exception.Message)
        }
    }
    Write-Host ''
}

# ---------------------------------------------------------------------------
# 开始
# ---------------------------------------------------------------------------

Head ("BCRM 客户管理系统 · Web 版启动   模式={0}  范围={1}" -f $Mode, $Service)
Info ("项目根目录：{0}" -f $Root)

if ($Stop) {
    Stop-Services
    exit 0
}

$totalSteps = if ($Service -eq 'all') { 6 } elseif ($Service -eq 'backend') { 3 } else { 3 }
$sn = 0

# ---------------------------------------------------------------------------
# 1. 环境自检
# ---------------------------------------------------------------------------

$sn++
Step $sn $totalSteps '环境自检'

$needBackend  = ($Service -ne 'frontend')
$needFrontend = ($Service -ne 'backend')

if (-not (Test-Path -LiteralPath $Manifest))     { Die ("找不到后端工程：{0}" -f $Manifest) }
if (-not (Test-Path -LiteralPath (Join-Path $FrontendDir 'package.json'))) {
    Die ("找不到前端工程：{0}" -f (Join-Path $FrontendDir 'package.json'))
}

if ($needBackend) {
    if (-not $CargoExe) {
        Die @'
找不到 cargo（Rust 工具链）。请先安装 Rust：
    https://rustup.rs/
安装后重开一个命令行窗口，再运行本脚本。
'@
    }
    Ok ("cargo  : {0}" -f $CargoExe)
}

if ($needFrontend) {
    if (-not $NpmCmd) {
        Die @'
找不到 npm（Node.js）。请先安装 Node.js 18 或更高版本：
    https://nodejs.org/zh-CN/download
安装后重开一个命令行窗口，再运行本脚本。
'@
    }
    $nodeVer = ''
    if ($NodeExe) { try { $nodeVer = (& $NodeExe -v) } catch { } }
    Ok ("node   : {0} {1}" -f $NodeExe, $nodeVer)
    Ok ("npm    : {0}" -f $NpmCmd)
    if ($Registry) {
        $env:npm_config_registry = $Registry
        Ok ("npm 镜像: {0}" -f $Registry)
    }
}

# ---------------------------------------------------------------------------
# 2. 编译后端
# ---------------------------------------------------------------------------

$ApiPort = 0

if ($needBackend) {
    $sn++
    Step $sn $totalSteps '编译后端（首次约 5~8 分钟，之后是增量，很快）'

    if ($NoBuild) {
        if (-not (Test-Path -LiteralPath $BackendExe)) {
            Die ("指定了 -NoBuild，但后端产物不存在：{0}" -f $BackendExe)
        }
        Warn ("已跳过编译，直接使用：{0}" -f $BackendExe)
    } else {
        Say '      cargo build --release ...' 'DarkGray'
        $sw = [System.Diagnostics.Stopwatch]::StartNew()
        & $CargoExe build --release --manifest-path $Manifest
        $rc = $LASTEXITCODE
        $sw.Stop()
        if ($rc -ne 0) {
            Die ("后端编译失败（cargo 退出码 {0}）。上面的输出就是原因。" -f $rc)
        }
        Ok ("编译完成，耗时 {0:N1} 秒" -f $sw.Elapsed.TotalSeconds)
    }

    if (-not (Test-Path -LiteralPath $BackendExe)) {
        Die ("编译结束但没找到产物：{0}" -f $BackendExe)
    }

    # --- 数据库自检（顺便把落点打印出来） ---
    Say '      数据库自检 ...' 'DarkGray'
    $chkOut = ''
    try {
        $chkOut = (& $BackendExe --db-check 2>&1 | Out-String)
        $chkRc = $LASTEXITCODE
    } catch {
        $chkRc = -1
        $chkOut = $_.Exception.Message
    }

    if ($chkRc -ne 0) {
        Write-Host $chkOut
        Die '数据库自检未通过，上面是完整报告。'
    }
    foreach ($line in ($chkOut -split "`r?`n")) {
        if ($line -match '^\s*(选用|数据行数|写探针|表白名单)\s*:') {
            Info ($line.Trim())
        }
    }
    Ok '数据库可读可写'
}

# ---------------------------------------------------------------------------
# 3. 端口协商
# ---------------------------------------------------------------------------

if ($needBackend) {
    $sn++
    Step $sn $totalSteps '端口协商'

    $ApiPort = Find-FreePort $Port
    if ($ApiPort -eq 0) { Die ("从 {0} 起连续 20 个端口都被占用，请用 -Port 指定别的端口。" -f $Port) }

    if ($ApiPort -ne $Port) {
        $owner = Get-ProcInfo (Get-PortOwnerPid $Port)
        $who = if ($owner) { "{0}（PID {1}）" -f $owner.ProcessName, $owner.Id } else { '未知进程' }
        Warn ("端口 {0} 已被 {1} 占用，自动改用 {2}" -f $Port, $who, $ApiPort)
    }
    Ok ("后端将监听 127.0.0.1:{0}" -f $ApiPort)
} else {
    $ApiPort = $Port
}

if ($needFrontend) {
    $WebPort = Find-FreePort $WebPort
    if ($WebPort -eq 0) { Die '前端端口连续 20 个都被占用，请用 -WebPort 指定。' }
    Ok ("前端将监听 127.0.0.1:{0}" -f $WebPort)
}

# ---------------------------------------------------------------------------
# 4. 启动后端
# ---------------------------------------------------------------------------

if ($needBackend) {
    $sn++
    Step $sn $totalSteps '启动后端 API（独立窗口）'

    $argLine = "--port $ApiPort"
    if ($DbPath) { $argLine += " --db `"$DbPath`"" }

    Info ("命令：bcrm-backend.exe {0}" -f $argLine)
    $q = [char]34
    $cmdLine = "/k title BCRM 后端 API 127.0.0.1:{0} & {1}{2}{1} {3}" -f $ApiPort, $q, $BackendExe, $argLine
    Start-Process -FilePath 'cmd.exe' -ArgumentList $cmdLine `
        -WorkingDirectory $BackendDir -WindowStyle Normal | Out-Null

    if (-not (Wait-Port $ApiPort 90)) {
        Die ("后端在 {0} 秒内没有监听 127.0.0.1:{1}。请查看刚打开的「BCRM 后端 API」窗口里的报错。" -f 90, $ApiPort)
    }

    $health = Invoke-Json ("http://127.0.0.1:{0}/api/v1/meta/health" -f $ApiPort)
    if ($health -and $health.code -eq 0) {
        $d = $health.data
        Ok ("健康检查通过：{0} 张表 / {1} 行数据" -f $d.table_count, $d.total_rows)
        Info ("数据库：{0}" -f $d.db_path)
    } else {
        Warn '端口已通，但 /meta/health 没有返回预期结果（后端可能还在初始化），继续。'
    }
}

# ---------------------------------------------------------------------------
# 5. 前端依赖
# ---------------------------------------------------------------------------

if ($needFrontend) {
    $sn++
    Step $sn $totalSteps '前端依赖（npm install）'

    $nm   = Join-Path $FrontendDir 'node_modules'
    $lock = Join-Path $FrontendDir 'package-lock.json'

    $needInstall = $Reinstall -or (-not (Test-Path -LiteralPath $nm)) `
                             -or (-not (Test-Path -LiteralPath (Join-Path $nm 'vite\package.json')))

    if (-not $needInstall) {
        Ok '依赖已就绪，跳过安装（要强制重装请加 -Reinstall）'
    } else {
        if ($Reinstall -and (Test-Path -LiteralPath $lock)) {
            Say '      npm ci（干净重装）...' 'DarkGray'
            $rc = Invoke-Npm @('ci', '--no-audit', '--no-fund')
        } else {
            Say '      npm install ...' 'DarkGray'
            $rc = Invoke-Npm @('install', '--no-audit', '--no-fund')
        }
        if ($rc -ne 0) {
            Die @'
前端依赖安装失败。常见原因：
  · 网络不通 / 需要代理 —— 可加 npm 镜像参数重试：
        启动Web服务.bat -Registry https://registry.npmmirror.com
  · Node 版本过低（本项目需要 Node 18+）
  · node_modules 处于半损坏状态 —— 加 -Reinstall 重来
'@
        }
        Ok '依赖安装完成'
    }
}

# ---------------------------------------------------------------------------
# 6. 启动前端
# ---------------------------------------------------------------------------

if ($needFrontend) {
    $sn++
    if ($Mode -eq 'release') {
        Step $sn $totalSteps '构建前端并启动静态服务（交付模式）'

        # 相对路径 + vite 的 /api 反代 ⇒ 前端产物与「后端端口」彻底解耦
        $env:VITE_BCRM_API_BASE = '/api/v1'
        $env:BCRM_API_TARGET    = "http://127.0.0.1:$ApiPort"

        if ($NoBuild -and (Test-Path -LiteralPath (Join-Path $FrontendDir 'dist\index.html'))) {
            Warn '已跳过构建，直接使用现有 dist/'
        } else {
            Say '      npm run build ...' 'DarkGray'
            $rc = Invoke-Npm @('run', 'build')
            if ($rc -ne 0) { Die '前端构建失败（npm run build）。' }
            Ok '前端构建完成 → frontend\dist'
        }

        Start-Process -FilePath 'cmd.exe' `
            -ArgumentList ("/k title BCRM 前端页面 http://127.0.0.1:{0} & npm run preview -- --port {0} --strictPort" -f $WebPort) `
            -WorkingDirectory $FrontendDir -WindowStyle Normal | Out-Null
    } else {
        Step $sn $totalSteps '启动前端开发服务（独立窗口，热更新）'

        $env:VITE_BCRM_API_BASE = '/api/v1'
        $env:BCRM_API_TARGET    = "http://127.0.0.1:$ApiPort"

        Start-Process -FilePath 'cmd.exe' `
            -ArgumentList ("/k title BCRM 前端页面 http://127.0.0.1:{0} & npm run dev -- --port {0} --strictPort" -f $WebPort) `
            -WorkingDirectory $FrontendDir -WindowStyle Normal | Out-Null
    }

    if (-not (Wait-Port $WebPort 120)) {
        Warn ("前端在 120 秒内没有监听 127.0.0.1:{0}，请查看「BCRM 前端页面」窗口。查看页面可能会失败。" -f $WebPort)
    } else {
        Ok ("前端已就绪：http://127.0.0.1:{0}/" -f $WebPort)
    }
}

# ---------------------------------------------------------------------------
# 完成
# ---------------------------------------------------------------------------

$url = "http://127.0.0.1:$WebPort/"

Head '启动完成'
if ($needBackend)  { Info ("后端 API ：http://127.0.0.1:{0}/api/v1   （健康检查 /api/v1/meta/health）" -f $ApiPort) }
if ($needFrontend) { Info ("前端页面 ：{0}" -f $url) }
Write-Host ''

if ($needBackend) {
    Write-Host '  后端与前端的日志都在各自独立窗口里；' -ForegroundColor DarkGray
    Write-Host '  结束服务：关掉那两个窗口，或运行  启动Web服务.bat -Stop' -ForegroundColor DarkGray
}
if ($needFrontend -and -not $NoOpen) {
    Write-Host ''
    Write-Host ("  正在打开浏览器：{0}" -f $url) -ForegroundColor Cyan
    try { Start-Process $url | Out-Null } catch { Warn ("没能自动打开浏览器，请手动访问 {0}" -f $url) }
}
Write-Host ''
